import json
import os
from pathlib import Path

class History:
    def __init__(self, path):
        self.path=Path(path)
        try:
            self.data=json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(self.data.get('latest'),dict) or not isinstance(self.data.get('records'),list):
                raise ValueError('invalid history')
        except (OSError,ValueError,AttributeError):
            self.data={'latest':{},'records':[]}
    def rows(self,day):
        return [dict(r) for r in self.data['latest'].get(day,{}).values()]
    def add(self,row):
        previous=self.data['latest'].setdefault(row['date'],{}).get(row['time'])
        result=dict(row)
        result['delta']=None
        if row['booked'] is not None:
            if previous and previous.get('booked') is not None and previous['capacity']==row['capacity']:
                result['delta']=row['booked']-previous['booked']
                result['previous_checked']=previous['checked']
            self.data['latest'][row['date']][row['time']]=result
            self.data['records'].append(result)
            self.data['records']=self.data['records'][-5000:]
            self.save()
        elif previous:
            result=dict(previous)
            result['status']='확인 실패 · 이전 기록 표시: '+row['status']
            result['cached']=True
            result['delta']=None
        return result
    def save(self):
        tmp=self.path.with_suffix('.tmp')
        tmp.write_text(json.dumps(self.data,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(tmp,self.path)
