# IShellLinkW and IPersistFile preserve Unicode shortcut names on every locale.
if ($null -eq ('GalaxyShortcutNative' -as [type])) {
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
[ComImport, Guid("000214F9-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IGalaxyShellLinkW {
 void GetPath([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder path, int max, IntPtr data, uint flags);
 void GetIDList(out IntPtr id);
 void SetIDList(IntPtr id);
 void GetDescription([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder text, int max);
 void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string text);
 void GetWorkingDirectory([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder text, int max);
 void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string text);
 void GetArguments([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder text, int max);
 void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string text);
 void GetHotkey(out short hotkey);
 void SetHotkey(short hotkey);
 void GetShowCmd(out int cmd);
 void SetShowCmd(int cmd);
 void GetIconLocation([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder path, int max, out int index);
 void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string path, int index);
 void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string path, uint reserved);
 void Resolve(IntPtr hwnd, uint flags);
 void SetPath([MarshalAs(UnmanagedType.LPWStr)] string path);
}
public static class GalaxyShortcutNative {
 static object Create() {
  return Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("00021401-0000-0000-C000-000000000046")));
 }
 public static void Save(string file, string target, string args, string working, string icon, string description) {
  object obj=Create();
  try {
   IGalaxyShellLinkW link=(IGalaxyShellLinkW)obj;
   link.SetPath(target);link.SetArguments(args);link.SetWorkingDirectory(working);
   link.SetIconLocation(icon,0);link.SetDescription(description);link.SetShowCmd(1);
   ((IPersistFile)obj).Save(file,true);
  } finally {Marshal.FinalReleaseComObject(obj);}
 }
 public static string[] Read(string file) {
  object obj=Create();
  try {
   ((IPersistFile)obj).Load(file,0);
   IGalaxyShellLinkW link=(IGalaxyShellLinkW)obj;
   StringBuilder target=new StringBuilder(32768),args=new StringBuilder(32768),icon=new StringBuilder(32768);
   int index;link.GetPath(target,target.Capacity,IntPtr.Zero,0);link.GetArguments(args,args.Capacity);link.GetIconLocation(icon,icon.Capacity,out index);
   return new string[]{target.ToString(),args.ToString(),icon.ToString()+","+index};
  } finally {Marshal.FinalReleaseComObject(obj);}
 }
}
'@
}
