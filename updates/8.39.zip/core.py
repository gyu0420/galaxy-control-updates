from datetime import datetime, timezone, timedelta

KST = timezone(timedelta(hours=9))

def today():
    return datetime.now(KST).date().isoformat()

def booked_estimate(capacity, selectable):
    if not isinstance(selectable, int) or not 0 <= selectable <= capacity:
        raise ValueError('선택 가능한 수량이 정원 범위를 벗어납니다.')
    return capacity - selectable
