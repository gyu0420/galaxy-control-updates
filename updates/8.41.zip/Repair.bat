@echo off
setlocal
cd /d "%~dp0"
set "GRP_ENV=%LOCALAPPDATA%\GRP\env"
set "GRP_PY=%GRP_ENV%\Scripts\python.exe"
if exist "%GRP_PY%" goto install
if not exist "%LOCALAPPDATA%\GRP" mkdir "%LOCALAPPDATA%\GRP"
where py >nul 2>nul
if errorlevel 1 goto plainpython
py -3 -m venv "%GRP_ENV%"
goto install
:plainpython
python -m venv "%GRP_ENV%"
:install
if not exist "%GRP_PY%" goto nopython
"%GRP_PY%" -m pip install --force-reinstall -r "%~dp0requirements.txt"
if errorlevel 1 goto failed
"%GRP_PY%" -m playwright install chromium
if errorlevel 1 goto failed
echo Repair finished. Open the desktop shortcut again.
pause
exit /b 0
:nopython
echo Python 3.10 or newer is required.
pause
exit /b 1
:failed
echo Repair failed. Check the message above.
pause
exit /b 1
