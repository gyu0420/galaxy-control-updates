"""같은 와이파이용 읽기/확인 요청 화면. 외부 서버나 터널을 사용하지 않습니다."""
import json
import secrets
import socket
import threading
from datetime import date, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
from core import today

class Mobile:
    def __init__(self, events):
        self.events=events
        self.lock=threading.Lock()
        self.token=secrets.token_urlsafe(24)
        self.state={'rows':[], 'status':'PC에서 확인 시작을 누르세요.', 'summary':'아직 확인하지 않았습니다.', 'date':today(), 'busy':False}
        self.server=None
        self.url=None

    def update(self, **values):
        with self.lock:
            self.state.update(values)

    def start(self):
        owner=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):
                pass
            def send_data(self, status, data, content_type='application/json; charset=utf-8'):
                body=data.encode('utf-8') if isinstance(data,str) else json.dumps(data,ensure_ascii=False).encode('utf-8')
                self.send_response(status)
                self.send_header('Content-Type',content_type)
                self.send_header('Content-Length',str(len(body)))
                self.send_header('Cache-Control','no-store')
                self.send_header('Referrer-Policy','no-referrer')
                self.send_header('X-Content-Type-Options','nosniff')
                self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'")
                self.end_headers()
                self.wfile.write(body)
            def authorized(self):
                token=parse_qs(urlsplit(self.path).query).get('key',[''])[0]
                if not secrets.compare_digest(token,owner.token):
                    self.send_data(403,{'error':'PC에 표시된 휴대폰 주소를 사용해 주세요.'})
                    return False
                return True
            def do_GET(self):
                if not self.authorized():
                    return
                path=urlsplit(self.path).path
                if path=='/':
                    self.send_data(200,(Path(__file__).parent/'mobile.html').read_text(encoding='utf-8'),'text/html; charset=utf-8')
                elif path=='/api/status':
                    with owner.lock:
                        payload=dict(owner.state)
                    self.send_data(200,payload)
                else:
                    self.send_data(404,{'error':'페이지 없음'})
            def do_POST(self):
                if not self.authorized():
                    return
                if urlsplit(self.path).path!='/api/scan':
                    self.send_data(404,{'error':'페이지 없음'})
                    return
                try:
                    size=int(self.headers.get('Content-Length','0'))
                    if not 0<size<=512:
                        raise ValueError('요청 형식 오류')
                    payload=json.loads(self.rfile.read(size))
                    day=payload['date']
                    chosen=date.fromisoformat(day)
                    now=date.fromisoformat(today())
                    if day!=chosen.isoformat() or not now<=chosen<=now+timedelta(days=60):
                        raise ValueError('오늘부터 60일 이내 날짜를 선택하세요.')
                    with owner.lock:
                        if owner.state['busy']:
                            self.send_data(409,{'error':'이미 확인 중입니다.'})
                            return
                        owner.state['busy']=True
                        owner.state['status']='휴대폰 확인 요청을 처리 중입니다.'
                    owner.events.put(('mobile_scan',day))
                    self.send_data(202,{'ok':True})
                except (ValueError,KeyError,TypeError) as exc:
                    self.send_data(400,{'error':str(exc)})
        self.server=ThreadingHTTPServer(('0.0.0.0',0),Handler)
        self.server.daemon_threads=True
        port=self.server.server_address[1]
        # 기본 경로의 인터페이스 주소만 확인하며 외부로 데이터 전송하지 않습니다.
        sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        try:
            sock.connect(('192.0.2.1',80))
            address=sock.getsockname()[0]
        except OSError:
            address=socket.gethostbyname(socket.gethostname())
        finally:
            sock.close()
        self.url=f'http://{address}:{port}/?key={self.token}'
        threading.Thread(target=self.server.serve_forever,daemon=True).start()
        return self.url

    def close(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
