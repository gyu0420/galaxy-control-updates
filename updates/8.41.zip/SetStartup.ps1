﻿param([ValidateSet('0','1')][string]$Enabled)
$ErrorActionPreference = 'Stop'
$startup = [Environment]::GetFolderPath('Startup')
New-Item -ItemType Directory -Path $startup -Force | Out-Null
$path = Join-Path $startup '갤럭시 관제소.lnk'
if ($Enabled -eq '0') {
    if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force }
    exit 0
}
 . (Join-Path $PSScriptRoot 'ShortcutNative.ps1')
[GalaxyShortcutNative]::Save($path, (Join-Path $env:LOCALAPPDATA 'GRP\env\Scripts\pythonw.exe'), ('"' + (Join-Path $PSScriptRoot 'launch.py') + '"'), $PSScriptRoot, (Join-Path $PSScriptRoot 'assets\robocrew.ico'), '갤럭시 관제소 자동 실행')
