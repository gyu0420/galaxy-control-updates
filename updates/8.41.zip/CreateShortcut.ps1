﻿$ErrorActionPreference = 'Stop'
$appFolder = $PSScriptRoot
$desktop = [Environment]::GetFolderPath('Desktop')
New-Item -ItemType Directory -Path $desktop -Force | Out-Null
. (Join-Path $PSScriptRoot 'ShortcutNative.ps1')
$shortcutPath = Join-Path $desktop '갤럭시 관제소.lnk'
$windowlessPython = Join-Path $env:LOCALAPPDATA 'GRP\env\Scripts\pythonw.exe'
if (Test-Path -LiteralPath $windowlessPython) {
    $target = $windowlessPython
    $arguments = '"' + (Join-Path $appFolder 'launch.py') + '"'
} else {
    $target = Join-Path $env:WINDIR 'System32\wscript.exe'
    $arguments = '"' + (Join-Path (Split-Path $appFolder -Parent) '갤럭시 관제소 실행.vbs') + '"'
}
[GalaxyShortcutNative]::Save($shortcutPath, $target, $arguments, $appFolder, (Join-Path $appFolder 'assets\robocrew.ico'), '갤럭시 관제소 · 예약현황과 갤럭시 무전기')
