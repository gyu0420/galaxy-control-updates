"""Local RPG progress, independent from reservation and chat data."""
import json
from pathlib import Path

STAGES=(
    (1,'새싹 크루','CH.1 첫 출동','말랑별의 별빛 코어가 사라졌다! 새싹 크루, 출동!','#76d9ff','하트 빔'),
    (5,'스타 크루','CH.2 별빛 숲','숲을 지킨 크루에게 별빛 망토가 생겼다. 코어의 흔적을 찾자!','#65f5cf','별빛 연사'),
    (10,'가디언 크루','CH.3 달의 성','달의 성에 도착! 날개를 펼쳐 외계 군단을 돌파하자.','#bdadff','문라이트 실드'),
    (20,'오로라 크루','CH.4 오로라 항로','되찾은 코어가 오로라로 빛난다. 마지막 항로를 열자!','#ff80b5','오로라 폭풍'),
    (30,'갤럭시 크루','CH.5 은하의 수호자','말랑별에 평화가 돌아왔다! 새로운 은하를 향해 모험은 계속!','#ffe15a','갤럭시 하트'),
)

class CrewProgress:
    def __init__(self,path):
        self.path=Path(path);self.level=1;self.xp=0;self.kills=0;self.waves=0;self.save_error=False
        try:
            data=json.loads(self.path.read_text(encoding='utf-8'))
            for key in ('level','xp','kills','waves'):
                value=data[key]
                if type(value) is not int or value<0:raise ValueError('invalid progress')
            if not 1<=data['level']<=9999 or data['xp']>=100+25*(data['level']-1):raise ValueError('invalid level')
            self.level=data['level'];self.xp=data['xp'];self.kills=data['kills'];self.waves=data['waves']
        except (OSError,ValueError,KeyError,TypeError):pass
    @property
    def needed(self):return 100+25*(self.level-1)
    @property
    def stage(self):return next(s for s in reversed(STAGES) if self.level>=s[0])
    @property
    def stage_index(self):return STAGES.index(self.stage)
    def win(self):
        old=self.level;self.kills+=3;self.waves+=1;self.xp+=30
        while self.xp>=self.needed and self.level<9999:
            self.xp-=self.needed;self.level+=1
        if self.level==9999:self.xp=min(self.xp,self.needed-1)
        self.save();return self.level>old
    def save(self):
        try:
            tmp=self.path.with_suffix('.tmp')
            tmp.write_text(json.dumps({k:getattr(self,k) for k in ('level','xp','kills','waves')}),encoding='utf-8');tmp.replace(self.path);self.save_error=False
        except OSError:self.save_error=True
