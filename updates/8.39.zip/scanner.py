"""공개 수량 선택 화면을 확인합니다. 예약/결제 단계는 호출하지 않습니다."""
import re
import time
from datetime import datetime
from urllib.parse import urlencode
from core import KST, booked_estimate
BASE='https://booking.naver.com/booking/12/bizes/1666056/items/7946646'
SLOT=re.compile(r'^(오전|오후)\s*\d{1,2}:\d{2}$')
INCREASE=re.compile(r'^수량 증가, 현재')
class Stopped(Exception):pass

def check_stop(stop):
    if stop.is_set():raise Stopped('확인을 중지했습니다.')

def reject_block(page):
    text=page.locator('body').inner_text(timeout=5000)
    if re.search(r'과도한 접근 요청|서비스 이용이 제한되었습니다|Too Many Requests|rate limit',text,re.I):
        raise RuntimeError('네이버에서 과도한 접근으로 이용을 제한했습니다. 자동 확인을 중단합니다. 제한 해제 시점은 확인할 수 없습니다.')
    if re.search(r'비정상적인 접근|자동화된|자동입력 방지|로봇이 아닙니다|Verify you are human|Access Denied|unusual traffic',text,re.I):
        raise RuntimeError('네이버에서 접근 확인을 요청했습니다. 자동 확인을 중단합니다.')

def wait_slots(page,stop):
    end=time.monotonic()+30
    while time.monotonic()<end:
        check_stop(stop);reject_block(page)
        slots=page.get_by_role('button',name=SLOT).all_text_contents()
        if slots:return slots
        if page.get_by_text('예매 가능한 시간이 없습니다.',exact=True).count():return []
        time.sleep(.25)
    raise RuntimeError('회차 정보를 불러오지 못했습니다.')

def current(button):
    found=re.search(r'현재\s*(\d+)',button.inner_text(timeout=3000))
    if not found:raise RuntimeError('수량 버튼 형식이 바뀌었습니다.')
    return int(found.group(1))

def measure(page,capacity,stop,progress):
    button=page.get_by_role('button',name=INCREASE).nth(0)
    button.wait_for(state='visible',timeout=15000)
    value=current(button)
    if value!=0:raise RuntimeError('초기 수량이 0이 아닙니다. 이번 회차는 계산하지 않습니다.')
    while True:
        check_stop(stop)
        if value>capacity:raise RuntimeError('선택 수량이 정원보다 큽니다. 판매 설정을 확인하세요.')
        if value%25==0:
            progress(value);reject_block(page)
        if not button.is_enabled():return value
        button.click(timeout=5000)
        after=current(button)
        if after>value:
            value=after;continue
        if after<value:raise RuntimeError('확인 도중 수량이 변경됐습니다.')
        # 응답 지연을 상한으로 잘못 읽지 않도록 기다린 뒤 재확인
        end=time.monotonic()+1.2
        while after==value and time.monotonic()<end:
            check_stop(stop);time.sleep(.1);after=current(button)
        if after>value:
            value=after;continue
        if after<value:raise RuntimeError('확인 도중 수량이 변경됐습니다.')
        for _ in range(2):
            check_stop(stop);reject_block(page)
            button.click(timeout=5000);time.sleep(.3);after=current(button)
            if after!=value:break
        if after==value:return value
        if after<value:raise RuntimeError('확인 도중 수량이 변경됐습니다.')
        value=after

class Scanner:
    # 한 작업 스레드 안에서 재사용: 날짜/회차 재확인마다 브라우저를 다시 시작하지 않음
    def __init__(self):self.play=None;self.browser=None
    def ensure(self):
        if self.browser is None or not self.browser.is_connected():
            if self.play:self.play.stop()
            from playwright.sync_api import sync_playwright
            self.play=sync_playwright().start()
            self.browser=self.play.chromium.launch(headless=True)
    def scan(self,day,capacity,stop,emit,target=None):
        self.ensure()
        context=self.browser.new_context(locale='ko-KR',timezone_id='Asia/Seoul',viewport={'width':1000,'height':850})
        page=context.new_page();page.set_default_timeout(10000)
        results=[]
        try:
            url=BASE+'?'+urlencode({'lang':'ko','theme':'place','startDateTime':day+'T00:00:00+09:00'})
            page.goto(url,wait_until='domcontentloaded',timeout=45000)
            all_slots=wait_slots(page,stop)
            if target and target not in all_slots:raise RuntimeError('선택 회차가 현재 예매 화면에 없습니다. 이전 기록을 확인하세요.')
            slots=[target] if target else all_slots
            emit('slots',{'date':day,'slots':all_slots,'target':target})
            if not slots:
                emit('status','예매 가능한 회차 없음 · 마감/휴무/매진 여부는 확인 불가. 이전 기록은 그대로 표시합니다.')
                return []
            for index,slot in enumerate(slots):
                check_stop(stop);started=time.monotonic()
                emit('status',f'{slot} 확인 중 · {index+1}/{len(slots)}개 회차')
                try:
                    if index:
                        # 이전 버전의 reload + goto 두 번을 한 번으로 줄임
                        page.reload(wait_until='domcontentloaded',timeout=45000)
                        wait_slots(page,stop)
                    page.get_by_role('button',name=slot,exact=True).click()
                    m,d=map(int,day.split('-')[1:])
                    page.get_by_role('heading',name=re.compile(rf'^{m}\.\s*{d}\(.*{re.escape(slot)}')).wait_for(timeout=10000)
                    def progress(count):
                        emit('progress',{'value':100*(index+count/(capacity+1))/len(slots),'text':f'{slot} · 수량 {count}장 점검 중'})
                    selectable=measure(page,capacity,stop,progress)
                    row={'date':day,'time':slot,'capacity':capacity,'selectable':selectable,'booked':booked_estimate(capacity,selectable),'checked':datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S'),'status':'확인 완료 · 선택 상한 기준 추정','seconds':round(time.monotonic()-started,1)}
                except Stopped:raise
                except Exception as exc:
                    if '자동 확인을 중단' in str(exc):raise
                    row={'date':day,'time':slot,'capacity':capacity,'selectable':None,'booked':None,'checked':datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S'),'status':str(exc),'seconds':round(time.monotonic()-started,1)}
                results.append(row);emit('row',row)
                emit('progress',{'value':100*(index+1)/len(slots),'text':f'{index+1}/{len(slots)}개 회차 확인 완료'})
            return results
        finally:context.close()
    def close(self):
        if self.browser:self.browser.close()
        if self.play:self.play.stop()

def scan(day,capacity,stop,emit,target=None):
    scanner=Scanner()
    try:return scanner.scan(day,capacity,stop,emit,target)
    finally:scanner.close()
