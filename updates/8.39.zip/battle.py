"""Native, responsive pixel playground. No external animation assets."""
import math
from pathlib import Path
from crew_progress import CrewProgress
from PySide6.QtCore import Qt, QTimer, QRectF
from PySide6.QtGui import QColor, QPainter, QPen, QFont
from PySide6.QtWidgets import QWidget

class CrewBattle(QWidget):
    ROBOT=('000011110000','000010010000','001111111100','011111111110','011001100110','011001100110','011111111110','001110011100','000111111000','001111111100','011111111110','011001100110','000110011000')
    ALIEN=('001000100','000101000','001111100','011010110','111111111','101111101','101000101','000101000')
    def __init__(self,busy,parent=None,progress_path=None):
        super().__init__(parent);self.busy=busy;self.frame=0;self.cheer_until=0
        self.progress=CrewProgress(progress_path or Path(__file__).resolve().parent/'crew_progress.json');self.levelup_until=0
        self.setFixedHeight(160)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip('클릭하면 로보크루가 하트 필살기를 사용해요!')
        self.timer=QTimer(self);self.timer.timeout.connect(self.step);self.timer.start(80)
    def step(self):
        if self.isVisible():
            self.frame+=1
            if self.frame%150==108:
                if self.progress.win():self.levelup_until=self.frame+70
            self.update()
    def mousePressEvent(self,event):
        self.cheer_until=self.frame+65;self.update()
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing,False)
        p.fillRect(self.rect(),QColor('#0b1028'));p.setPen(QPen(QColor('#3553c4'),1));p.drawRect(self.rect().adjusted(0,0,-1,-1))
        # Fit one entire arena at every supported window width.
        scale=min(self.width()/960,self.height()/190);p.translate((self.width()-960*scale)/2,(self.height()-190*scale)/2);p.scale(scale,scale)
        t=self.frame;phase=t%150;cheer=t<self.cheer_until
        def rect(x,y,w,h,c):p.fillRect(QRectF(x,y,w,h),QColor(c))
        def text(x,y,w,h,s,c='#aabbe8',size=11):
            f=QFont('Galmuri11');f.setPixelSize(size);p.setFont(f);p.setPen(QColor(c));p.drawText(QRectF(x,y,w,h),Qt.AlignmentFlag.AlignCenter,s)
        def sprite(pattern,x,y,size,color):
            for row,line in enumerate(pattern):
                for col,v in enumerate(line):
                    if v=='1':rect(x+col*size,y+row*size,size,size,color)
        def heart(x,y,size,color):sprite(('0110110','1111111','1111111','0111110','0011100','0001000'),x,y,size,color)
        for i in range(62):
            x=(i*173+37)%950;y=29+(i*61)%118
            rect(x,y,2 if i%7 else 3,2 if i%7 else 3,'#637bc9' if (i+t//8)%4 else '#ffd984')
        # Crescent planet, tiny orbiting UFO, and candy-coloured skyline.
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#bdadff'));p.drawEllipse(QRectF(845,43,28,28));p.setBrush(QColor('#0b1028'));p.drawEllipse(QRectF(853,38,25,26))
        ux=690+math.sin(t/28)*38;rect(ux,36,25,5,'#76d9ff');rect(ux-8,41,41,5,'#bdadff');rect(ux+3,46,4,3,'#ffe15a');rect(ux+18,46,4,3,'#ff80b5')
        rect(18,158,924,2,'#4259aa');rect(18,160,924,22,'#101a3c')
        for i in range(30):rect(20+i*31,173,15,2,'#273763')
        for x,h,c in [(36,20,'#223265'),(63,34,'#2e3570'),(89,24,'#223265'),(891,22,'#223265'),(918,31,'#2e3570')]:
            rect(x,158-h,20,h,c);rect(x+5,164-h,4,4,'#ffe15a')
        text(16,8,260,18,'ROBO CREW  /  우주 수호대','#76d9ff',12)
        text(693,8,250,18,'ALIEN FRIENDS  /  말랑 침공!','#ff9dca',12)
        level,name,chapter,story,main_color,skill=self.progress.stage
        text(317,8,320,18,f'LV.{self.progress.level}  {name}','#ffe15a',12)
        # Three friendly robots hop and launch sparkling heart bolts.
        for i,(base,c) in enumerate([(165,'#76d9ff'),(238,'#bdadff'),(311,'#65f5cf')]):
            if i==0:c=main_color
            bob=round(math.sin(t/6+i)*3);x=base+(10 if 30<phase<75 else 0);y=91+bob
            if self.progress.stage_index>=1:
                sprite(('10001','11011','11111','01110'),x+11,y-13,4,'#ffe15a')
            if self.progress.stage_index>=2:
                sprite(('1000','1100','1110','1111','0111'),x-18,y+20,4,c)
                sprite(('0001','0011','0111','1111','1110'),x+48,y+20,4,c)
            if self.progress.stage_index>=4:
                for j in range(4):
                    heart(x-12+j*22,y-27+math.sin(t/8+j)*4,1,'#ffe15a')
            if self.progress.stage_index>=3:
                p.setPen(QPen(QColor(c),2));p.setBrush(Qt.BrushStyle.NoBrush);p.drawEllipse(QRectF(x-12,y-20,74,82));p.setPen(Qt.PenStyle.NoPen)
            rect(x+3,150,42,4,'#1c2e61');sprite(self.ROBOT,x,y,4,c)
            rect(x+12,y+16,8,3 if t%55<50 else 1,'#102045');rect(x+28,y+16,8,3 if t%55<50 else 1,'#102045')
            rect(x+8,y+26,4,3,'#ff9dca');rect(x+36,y+26,4,3,'#ff9dca');heart(x+19,y+38,1,'#ffe15a')
            rect(x+48,y+30,9,4,c);rect(x+55,y+26,5,6,'#ffe15a')
        # Aliens wobble, bounce on impact, then happily recover.
        for i,(base,c) in enumerate([(604,'#ff80b5'),(686,'#b6ef92'),(769,'#ffc58a')]):
            if phase>=108:
                heart(base+10,110-(phase-108),2,c)
                continue
            hit=80<phase<108;y=114+round(math.sin(t/7+i)*5)-(12 if hit else 0);x=base+round(math.sin(t/13+i)*5)
            rect(x,151,40,4,'#1c2e61');sprite(self.ALIEN,x,y,4,c)
            rect(x+11,y+15,3,4,'#172040');rect(x+23,y+15,3,4,'#172040');rect(x+4,y+22,4,3,'#ffb2cf');rect(x+29,y+22,4,3,'#ffb2cf')
            if hit:heart(x+11,y-18,2,'#ff80b5')
        # Both sides fire soft stars/hearts; no hurt or frightening effects.
        if 25<phase<90 or cheer:
            progress=(phase-25)/65 if not cheer else (t%28)/28
            for i in range(3+self.progress.stage_index):
                x=375+progress*230;y=105+math.sin(progress*math.pi*2+i)*13
                heart(x,y+i*7,2,'#ff80b5' if i%2 else '#ffe15a');rect(x-12,y+4,7,2,'#76d9ff')
        if 108<phase<142:
            x=620-(phase-108)/34*235
            for i in range(3):
                y=111+i*9;rect(x+i*20,y,10,3,'#bdadff');rect(x+4+i*20,y-4,3,11,'#bdadff')
        if 80<phase<110 or cheer:
            for i in range(12):
                a=i*math.pi/6;radius=18+(phase%30)*1.4;rect(555+math.cos(a)*radius,110+math.sin(a)*radius,4,4,['#ffe15a','#ff80b5','#65f5cf'][i%3])
            text(422,62,210,20,skill+'! 뿅뿅!','#ffe15a',12)
        else:text(404,54,180,22,'말랑별을 지켜라!' if not self.busy() else '예약 확인도 함께 출동!','#b6c9ff',12)
        text(255,166,450,19,'LEVEL UP! 진화 파워 충전!' if t<self.levelup_until else '처치 완료! 다음 출동 준비' if phase>=108 else '클릭하면 하트 필살기!  ·  자동 전투 진행 중','#ffe15a' if phase>=108 else '#aabbe8',11)
        p.end()
