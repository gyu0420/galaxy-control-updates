"""Full-day schedules survive booking cutoffs and application restarts."""
import json,re
from datetime import date
from pathlib import Path
from updater import atomic_json,base_dir

def normalize_times(values):
    result=set()
    for value in values:
        text=str(value).strip()
        match=re.fullmatch(r'(오전|오후)\s*(\d{1,2}):(\d{2})',text)
        if match:
            period,h,m=match.groups();h=int(h);m=int(m)
            if not 1<=h<=12 or not 0<=m<=59:raise ValueError('공연 시각이 올바르지 않습니다: '+text)
            h=h%12+(12 if period=='오후' else 0)
        else:
            match=re.fullmatch(r'(\d{1,2}):(\d{2})',text)
            if not match:raise ValueError('시각은 13:00, 15:00처럼 입력해 주세요.')
            h,m=map(int,match.groups())
            if not 0<=h<=23 or not 0<=m<=59:raise ValueError('공연 시각이 올바르지 않습니다: '+text)
        result.add(f'{h:02d}:{m:02d}')
    return sorted(result)

class PerformanceSchedule:
    def __init__(self,root):
        self.path=base_dir()/'performance_schedule.json'
        defaults=json.loads((Path(root)/'schedule_defaults.json').read_text(encoding='utf-8'))
        try:self.data=json.loads(self.path.read_text(encoding='utf-8'))
        except (OSError,ValueError):self.data=defaults
        if not isinstance(self.data.get('weekly'),dict):self.data=defaults
        self.data.setdefault('overrides',{});self.data.setdefault('observed',{})
    @property
    def duration(self):return int(self.data.get('duration_minutes',60))
    def times(self,day):
        # Explicit holiday, cancellation and special-show overrides take priority.
        if day in self.data['overrides']:return normalize_times(self.data['overrides'][day])
        regular=normalize_times(self.data['weekly'].get(str(date.fromisoformat(day).weekday()),[]))
        return normalize_times(regular+self.data['observed'].get(day,[]))
    def observe(self,day,times):
        times=normalize_times(times)
        if not times:return # No tickets available is not proof of no performance.
        self.data['observed'][day]=normalize_times(self.data['observed'].get(day,[])+times)
        self.data['observed']={d:t for d,t in self.data['observed'].items() if d>=date.fromisoformat(day).replace(day=1).isoformat()}
        atomic_json(self.path,self.data)
    def save(self,weekly,duration,day=None,times=None,clear_override=False):
        if not 1<=int(duration)<=240:raise ValueError('공연 시간은 1~240분으로 입력해 주세요.')
        data=dict(self.data);data['weekly']={str(k):normalize_times(v) for k,v in weekly.items()};data['duration_minutes']=int(duration)
        data['overrides']=dict(self.data['overrides'])
        if day:
            date.fromisoformat(day)
            if clear_override:data['overrides'].pop(day,None)
            elif times is not None:data['overrides'][day]=normalize_times(times)
        atomic_json(self.path,data);self.data=data
