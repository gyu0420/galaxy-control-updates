"""Public visitor review snapshots. Store only hashed identifiers, never review text."""
import hashlib,json,re,time
from pathlib import Path
from updater import atomic_json
BRANDS=[('WHAT A BREAD','2046089192','#ffc68b'),('AURORA BISTRO','2055475522','#c6a2ff'),('AURORA LOUNGE','2093806444','#78d5ff')]
INTERVAL_MS=30*60*1000
# Stable DOM signals observed in Naver visitor review cards, excluding mutable text/reaction totals.
DOM_SNAPSHOT=r'''() => {
 const cards=[...document.querySelectorAll('li')].filter(e=>e.textContent.includes('방문일')&&e.textContent.includes('인증 수단')&&e.querySelector('time')&&e.querySelector('a[data-pui-click-code="profile"]'));
 const entries=cards.slice(0,30).map(e=>{
   const profile=e.querySelector('a[data-pui-click-code="profile"]').getAttribute('href').split('?')[0];
   const date=e.querySelector('time').parentElement.textContent;
   const visit=(e.textContent.match(/\d+번째 방문/)||[''])[0];
   return profile+'|'+date+'|'+visit;
 });
 const heading=[...document.querySelectorAll('h2,h3')].find(e=>/^리뷰\s*[\d,]+/.test(e.textContent.trim()));
 const count=heading ? Number((heading.textContent.match(/^리뷰\s*([\d,]+)/)||[])[1]?.replaceAll(',','')) : null;
 return {entries,count:Number.isFinite(count)?count:null};
}'''
class ReviewState:
    def __init__(self,path):
        self.path=Path(path)
        try:self.data=json.loads(self.path.read_text(encoding='utf-8'))
        except (OSError,ValueError):self.data={}
    def unread(self,place):return bool(self.data.get(place,{}).get('unread',False))
    def observe(self,place,snapshot):
        ids=snapshot['ids'];count=snapshot.get('count');old=self.data.get(place)
        if not ids and count!=0:raise ValueError('리뷰 목록을 확인하지 못했습니다.')
        unread=False if old is None else old.get('unread',False)
        if old is not None:
            known=set(old['known']);overlap=next((i for i,key in enumerate(ids) if key in known),None)
            # Only entries before an existing recent entry count as new. Reordering, deletion,
            # text edits and older reviews filling the bottom do not trigger the badge.
            if overlap is not None:unread=unread or any(key not in known for key in ids[:overlap])
            if count is not None and old.get('count') is not None and count>old['count']:unread=True
            elif ids and count is not None and old.get('count') is not None:unread=unread or count>old['count']
            elif ids and not old['known']:unread=True
            merged=list(dict.fromkeys(ids+old['known']))[:1000]
        else:merged=ids
        self.data[place]={'known':merged,'count':count,'unread':unread,'checked':time.time()};atomic_json(self.path,self.data)
        return unread
    def acknowledge(self,place):
        if place in self.data:
            self.data[place]['unread']=False;atomic_json(self.path,self.data)
class ReviewScanner:
    def __init__(self):self.play=None;self.browser=None
    def fetch(self,place):
        from playwright.sync_api import sync_playwright
        from scanner import reject_block
        if self.browser is None:
            self.play=sync_playwright().start();self.browser=self.play.chromium.launch(headless=True)
        context=self.browser.new_context(locale='ko-KR',timezone_id='Asia/Seoul')
        try:
            page=context.new_page();page.set_default_timeout(10000)
            page.goto('https://m.place.naver.com/restaurant/'+place+'/review/visitor?reviewSort=recent',wait_until='domcontentloaded',timeout=30000)
            reject_block(page)
            recent=page.get_by_text('최신순',exact=True)
            recent.wait_for(state='visible',timeout=15000);recent.click()
            deadline=time.monotonic()+15
            while time.monotonic()<deadline:
                reject_block(page);snapshot=page.evaluate(DOM_SNAPSHOT)
                if snapshot['entries'] or snapshot.get('count')==0:
                    return {'ids':[hashlib.sha256(x.encode()).hexdigest() for x in snapshot['entries']], 'count':snapshot['count']}
                time.sleep(.3)
            raise RuntimeError('방문자 리뷰 목록을 읽지 못했습니다.')
        finally:context.close()
    def close(self):
        if self.browser:self.browser.close()
        if self.play:self.play.stop()
