"""Anonymous ntfy relay. Room key encrypts messages before HTTPS publishing."""
import base64, hashlib, json, threading, urllib.request, urllib.error, uuid
from datetime import datetime
import websocket
from cryptography.fernet import Fernet, InvalidToken

class CloudChat:
    def __init__(self,events):
        self.events=events;self.room=None;self.generation=0;self.response=None;self.key=None;self.name='직원';self.code='';self.seen=set();self.lock=threading.Lock();self.sending=False
    def host(self,name):
        code='GRP-'+Fernet.generate_key().decode();self.connect(code,name);return code
    def connect(self,code,name):
        code=code.strip()
        if not code.startswith('GRP-'):raise ValueError('GRP-로 시작하는 방 코드를 입력해 주세요.')
        try:key=Fernet(code[4:].encode())
        except (ValueError,TypeError):raise ValueError('방 코드 형식이 올바르지 않습니다.')
        self.disconnect();self.key=key;self.name=name.strip()[:24] or '직원';self.code=code;self.seen=set();generation=self.generation
        topic='grp-'+hashlib.sha256(code.encode()).hexdigest()[:48];self.url='https://ntfy.sh/'+topic;url=self.url
        def pause(seconds):
            for _ in range(seconds):
                if generation!=self.generation:return False
                threading.Event().wait(1)
            return generation==self.generation
        def receive(event):
            if event.get('event')!='message':return
            try:item=json.loads(key.decrypt(event['message'].encode()))
            except (InvalidToken,ValueError,KeyError,TypeError):return
            self.deliver(item,generation)
        def poll(cursor):
            while generation==self.generation:
                try:
                    req=urllib.request.Request(url+'/json?poll=1&since='+cursor,headers={'User-Agent':'GalaxyReservationMonitor/8.2'})
                    with urllib.request.urlopen(req,timeout=15) as response:body=response.read(1024*1024)
                    if generation!=self.generation:return
                    self.events.put(('chat_status',{'connected':True,'text':'실시간 연결 불가 · 3초 간격 확인 모드로 연결됨'}))
                    for raw in body.splitlines():
                        event=json.loads(raw)
                        if event.get('event')=='message':cursor=event['id'];receive(event)
                except urllib.error.HTTPError as e:
                    if generation==self.generation:self.events.put(('chat_status',{'connected':False,'text':'무료 서비스 한도 또는 연결 오류: '+str(e.code)+' · 자동 결제는 없습니다.'}))
                    return
                except (OSError,ValueError):
                    if generation==self.generation:self.events.put(('chat_status',{'connected':False,'text':'연결 실패 · 3초 후 다시 연결합니다.'}))
                if not pause(3):return
        def read():
            cursor='12h';failures=0
            while generation==self.generation:
                ws=None
                try:
                    ws=websocket.create_connection(url.replace('https://','wss://')+'/ws?since='+cursor,timeout=12)
                    if generation!=self.generation:ws.close();return
                    self.response=ws;ws.settimeout(60);failures=0
                    while generation==self.generation:
                        raw=ws.recv()
                        if not raw:raise OSError('실시간 연결 종료')
                        if len(raw)>262144:raise ValueError('수신 메시지가 너무 큽니다.')
                        event=json.loads(raw)
                        if event.get('event')=='open':self.events.put(('chat_status',{'connected':True,'text':'실시간 무전 연결 · 새 메시지를 바로 수신합니다.'}))
                        if event.get('event')=='message':cursor=event['id'];receive(event)
                except websocket.WebSocketBadStatusException as e:
                    if generation!=self.generation:return
                    if getattr(e,'status_code',None)==429:
                        self.events.put(('chat_status',{'connected':False,'text':'무료 서비스 요청 한도에 걸렸습니다. 자동 결제는 없습니다.'}));return
                    self.events.put(('chat_status',{'connected':False,'text':'실시간 연결 불가 · 일반 확인 모드로 전환합니다.'}));poll(cursor);return
                except (OSError,ValueError,websocket.WebSocketException):
                    if generation!=self.generation:return
                    failures+=1
                    if failures>=2:
                        self.events.put(('chat_status',{'connected':False,'text':'실시간 연결 불가 · 일반 확인 모드로 전환합니다.'}));poll(cursor);return
                    self.events.put(('chat_status',{'connected':False,'text':'연결이 끊겨 3초 후 다시 연결합니다.'}))
                finally:
                    if ws:ws.close()
                    if self.response is ws:self.response=None
                if not pause(3):return
        threading.Thread(target=read,daemon=True).start()
    def deliver(self,item,generation):
        if generation!=self.generation:return
        if not isinstance(item,dict) or not all(isinstance(item.get(k),str) for k in ('id','name','text','time')):return
        with self.lock:
            if item.get('id') in self.seen:return
            self.seen.add(item['id'])
        self.events.put(('chat_message',{'name':str(item['name'])[:24],'text':str(item['text'])[:500],'time':str(item['time'])[:5]}))
    def send(self,text):
        if not self.key:raise OSError('무전방에 먼저 연결해 주세요.')
        if self.sending:raise OSError('이전 메시지를 전송 중입니다. 잠시 기다려 주세요.')
        self.sending=True;generation=self.generation;key=self.key;url=self.url
        item={'id':uuid.uuid4().hex,'name':self.name,'text':text[:500],'time':datetime.now().strftime('%H:%M')}
        encrypted=key.encrypt(json.dumps(item,ensure_ascii=False).encode())
        def publish():
            try:
                req=urllib.request.Request(url,data=encrypted,method='POST',headers={'Content-Type':'text/plain','Firebase':'no','User-Agent':'GalaxyReservationMonitor/8'})
                with urllib.request.urlopen(req,timeout=15) as response:response.read(10000)
                self.deliver(item,generation)
                if generation==self.generation:self.events.put(('chat_sent',text))
            except (OSError,ValueError) as e:
                if generation==self.generation:self.events.put(('chat_send_error','전송 실패 · 무료 한도 또는 연결을 확인하세요. 입력한 내용은 유지됩니다. '+str(e)))
            finally:self.sending=False
        threading.Thread(target=publish,daemon=True).start()
    def disconnect(self):
        self.generation+=1;self.key=None
        old=self.response;self.response=None
        if old:threading.Thread(target=old.close,daemon=True).start()
