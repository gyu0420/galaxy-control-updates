@echo off
setlocal
cd /d "%~dp0"
set "GRP_ENV=%LOCALAPPDATA%\GRP\env"
set "GRP_PY=%GRP_ENV%\Scripts\python.exe"
if exist "%GRP_PY%" goto check
if not exist "%LOCALAPPDATA%\GRP" mkdir "%LOCALAPPDATA%\GRP"
where py >nul 2>nul
if errorlevel 1 goto plainpython
py -3 -m venv "%GRP_ENV%"
goto install
:plainpython
python -m venv "%GRP_ENV%"
:install
if not exist "%GRP_PY%" goto nopython
"%GRP_PY%" -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 goto failed
"%GRP_PY%" -m playwright install chromium
if errorlevel 1 goto failed
goto run
:check
"%GRP_PY%" -c "from PySide6.QtWidgets import QApplication; import playwright; import cryptography; import websocket" >nul 2>nul
if errorlevel 1 goto install
:run
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CreateShortcut.ps1" >nul 2>nul
if not exist "%GRP_ENV%\Scripts\pythonw.exe" goto failed
start "" "%GRP_ENV%\Scripts\pythonw.exe" "%~dp0launch.py"
if errorlevel 1 goto failed
exit /b 0
:nopython
echo Python 3.10 or newer is required. Install from https://www.python.org/downloads/
exit /b 1
:failed
echo Setup or launch failed. Check the message above.
echo If setup was interrupted, run Repair.bat.
exit /b 1
