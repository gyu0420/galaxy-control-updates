﻿param([ValidateSet('0','1')][string]$Enabled)
$ErrorActionPreference = 'Stop'
$startup = [Environment]::GetFolderPath('Startup')
$path = Join-Path $startup '갤럭시 관제소.lnk'
if ($Enabled -eq '0') {
    if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force }
    exit 0
}
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($path)
$shortcut.TargetPath = Join-Path $env:LOCALAPPDATA 'GRP\env\Scripts\pythonw.exe'
$shortcut.Arguments = '"' + (Join-Path $PSScriptRoot 'launch.py') + '"'
$shortcut.WorkingDirectory = $PSScriptRoot
$shortcut.IconLocation = (Join-Path $PSScriptRoot 'assets\robocrew.ico') + ',0'
$shortcut.Description = '갤럭시 관제소 자동 실행'
$shortcut.Save()
