import runpy
import traceback
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
try:
    from updater import select_installation
    original=root
    if sys.platform=='win32':
        import subprocess
        subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(original/'CreateShortcut.ps1')],creationflags=subprocess.CREATE_NO_WINDOW,timeout=15,check=False)
    root=select_installation(root)
    sys.path.insert(0,str(root))
    # Import the updater shipped with the selected release.
    sys.modules.pop('updater',None)
    runpy.run_path(str(root/'app.py'),run_name='__main__')
except Exception:
    error=traceback.format_exc()
    try:
        import updater
        active=updater.base_dir()/'active_update.json'
        if root!=original and active.exists():
            import json
            data=json.loads(active.read_text())
            updater.atomic_json(active,{'path':data.get('previous',str(original))})
    except Exception:pass
    try:(root/'app_error.log').write_text(error,encoding='utf-8')
    except OSError:pass
    if sys.platform=='win32':
        import ctypes
        ctypes.windll.user32.MessageBoxW(None,'관제소를 실행하지 못했습니다.\n오류 내용은 프로그램 폴더의 app_error.log에 저장했습니다.\n설치 문제라면 Repair.bat을 실행하세요.','갤럭시 관제소 · 실행 오류',0x10)
    print(error)
    print('Error details saved to app_error.log')
    sys.exit(1)
