"""Per-user Windows startup preference, shared across app updates."""
import json, subprocess, sys
from pathlib import Path
from updater import atomic_json, base_dir

def preference():
    try:
        data=json.loads((base_dir()/'startup_preference.json').read_text(encoding='utf-8'))
        return data['enabled'] if isinstance(data.get('enabled'),bool) else None
    except (OSError,ValueError,KeyError):return None

def set_enabled(root,enabled):
    if sys.platform!='win32':raise RuntimeError('Windows에서 설정할 수 있습니다.')
    subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(Path(root)/'SetStartup.ps1'),'-Enabled',str(int(enabled))],check=True,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW,capture_output=True)
    atomic_json(base_dir()/'startup_preference.json',{'enabled':bool(enabled)})
