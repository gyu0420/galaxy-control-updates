"""Pixel professor and a countdown based on today's known performance slots."""
import math
import re
from datetime import datetime
from core import KST
from PySide6.QtCore import Qt, QRectF, QTimer
from PySide6.QtGui import QColor, QPainter, QFont
from PySide6.QtWidgets import QWidget

def countdown_message(rows=(), now=None, slots=None, schedule=None, duration_minutes=60):
    from datetime import timedelta
    from performance_schedule import normalize_times
    now = now or datetime.now(KST)
    if now.tzinfo is None:now=now.replace(tzinfo=KST)
    else:now=now.astimezone(KST)
    values=list(schedule) if schedule is not None else [r.get('time','') for r in rows if r.get('date')==now.date().isoformat()]+list(slots or [])
    if not values:
        return '오늘은 공연이 없는날이야..' if schedule is not None else '오늘 공연 일정을 불러오는 중이야!'
    try:times=normalize_times(values)
    except ValueError:return '공연 시각을 읽지 못했어.\n공연 일정 설정을 확인해 줘!'
    starts=[now.replace(hour=int(t[:2]),minute=int(t[3:]),second=0,microsecond=0) for t in times]
    ends=[t+timedelta(minutes=duration_minutes) for t in starts]
    upcoming=[t for t in starts if t>now]
    running=[(s,e) for s,e in zip(starts,ends) if s<=now<e]
    if running:
        start,end=running[-1];minutes=math.ceil((end-now).total_seconds()/60)
        if upcoming:
            left=math.ceil((upcoming[0]-now).total_seconds()/60);h,m=divmod(left,60)
            return f'지금 공연 중이야!\n다음은 {h}시간{m}분뒤 공연이야!'
        return f'지금 마지막 공연 중이야!\n약 {minutes}분 뒤 끝날 예정이야!'
    if upcoming:
        minutes=math.ceil((upcoming[0]-now).total_seconds()/60);h,m=divmod(minutes,60)
        return f'{h}시간{m}분뒤 공연이야!\n다음 공연 · {upcoming[0]:%H:%M}'
    return '오늘은 공연이 모두 다 끝났어!'

class PixelProfessor(QWidget):
    # White hair, round glasses, moustache and a lab coat, drawn on a pixel grid.
    SPRITE = (
        '    WWWWWWWW    ', '  WWWWWWWWWWWW  ', ' WWWWWWWWWWWWWW ',
        ' WWSSSSSSSSSSWW ', ' WSSBBBBBBBBSSW ', '  SBLEEBBLEELBS ',
        '  SBLEEBBLEELBS ', '  SSBBBBBBBBSS  ', '  SSSSSSSSSSSS  ', '   SSWWWWWWSS   ',
        '    SSSSSSSS    ', '   WWWWTTWWWW   ', '  WWWWWTTWWWWW  ',
        ' SWWWWWTTWWWWWS ', ' SWWWWWTTWWWWWS ', '  WWWWWTTWWWWW  ',
        '   WWWWWWWWWW   ', '    BBB  BBB    ', '   BBBB  BBBB   ')
    COLORS={'W':'#f1f4ff','S':'#ffc89c','B':'#293757','E':'#72e7f1','L':'#ffffff','T':'#ffe15a'}
    def __init__(self,parent=None):
        super().__init__(parent);self.message='오늘 공연 일정은 아직 확인 전이야!';self.setFixedHeight(194);self.frame=0
        self.timer=QTimer(self);self.timer.timeout.connect(self.animate);self.timer.start(140)
    def animate(self):
        if self.isVisible():self.frame+=1;self.update()
    def set_message(self,message):
        if message!=self.message:self.message=message;self.update()
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing,False)
        x=8;y=5;w=self.width()-16;h=71
        # Stepped corners and a square speech tail echo arcade dialog boxes.
        def block(x,y,w,h,color):p.fillRect(QRectF(x,y,w,h),QColor(color))
        block(x+4,y,w-8,h,'#638aff');block(x,y+4,w,h-8,'#638aff')
        block(x+5,y+3,w-10,h-6,'#101934');block(x+3,y+5,w-6,h-10,'#101934')
        block(x+8,y+7,w-16,2,'#2f437a')
        mid=self.width()/2
        block(mid-12,y+h,16,5,'#638aff');block(mid-8,y+h+5,12,5,'#638aff');block(mid-4,y+h+10,8,5,'#638aff')
        block(mid-9,y+h-2,10,6,'#101934');block(mid-5,y+h+4,6,5,'#101934')
        f=QFont('Galmuri11');f.setPixelSize(12);f.setBold(True);p.setFont(f)
        area=QRectF(x+7,y+12,w-14,h-20)
        p.setPen(QColor('#35265e'));p.drawText(area.translated(1,2),Qt.AlignmentFlag.AlignCenter|Qt.TextFlag.TextWordWrap,self.message)
        p.setPen(QColor('#ffe15a'));p.drawText(area,Qt.AlignmentFlag.AlignCenter|Qt.TextFlag.TextWordWrap,self.message)
        # Eight directional poses create a turn around the vertical axis.
        pose=(self.frame//4)%8
        front=pose in (0,1,7);back=pose in (3,4,5)
        squeeze=(1,.85,.6,.85,1,.85,.6,.85)[pose]
        scale=4;left=(self.width()-64*squeeze)/2;top=99
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#080e20'))
        p.drawEllipse(QRectF(mid-39,175,78,10))
        for r,line in enumerate(self.SPRITE):
            for c,v in enumerate(line):
                if v not in self.COLORS:continue
                if back:
                    if 3<=r<=10:v='W' if r<9 else 'S'
                    if r>=11 and v=='T':v='W'
                elif not front and 3<=r<=9:
                    v='W' if c<8 else 'S'
                    if r in (5,6) and c>=11:v='B' if c==11 else 'E'
                col=15-c if pose in (5,6,7) else c
                color=QColor(self.COLORS[v])
                if col>10 or r in (2,9,16):color=color.darker(125)
                if col<5 and v=='W':color=QColor('#ffffff')
                block(left+col*scale*squeeze,top+r*scale,scale*squeeze,scale,color.name())
        # Steel wrench with an open jaw, held next to the hand.
        toolx=left+64*squeeze+2 if pose<4 else left-13
        tooly=top+44
        block(toolx+4,tooly,5,24,'#8da6bd');block(toolx+4,tooly,2,24,'#e0f8ff')
        block(toolx,tooly-9,4,11,'#b9d7e8');block(toolx+9,tooly-9,4,11,'#b9d7e8')
        block(toolx+3,tooly-2,7,5,'#b9d7e8');block(toolx+3,tooly+12,7,5,'#ffc89c')
        # A tiny ginger cat blinks and swishes its tail beside the professor.
        cat=('O     O','OO   OO','OOOOOOO','OBBOBBO','OOPOOOO',' OOOOO ',' OOOOO ',' OO OO ')
        colors={'O':'#ffb465','B':'#27334e','P':'#ff7ea4'}
        cx=mid+47;cy=151
        for r,line in enumerate(cat):
            for c,v in enumerate(line):
                if v in colors:
                    color=colors[v]
                    if v=='B' and self.frame%30==0:color='#ffb465'
                    block(cx+c*3,cy+r*3,3,3,color)
        tail=3 if (self.frame//3)%2 else 0
        block(cx+21,cy+15,9,3,'#ffb465');block(cx+27,cy+6+tail,3,12-tail,'#ffb465')
        block(cx+3,cy+3,3,3,'#ff7ea4');block(cx+15,cy+3,3,3,'#ff7ea4')
