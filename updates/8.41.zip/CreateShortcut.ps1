﻿$ErrorActionPreference = 'Stop'
$appFolder = $PSScriptRoot
$desktop = [Environment]::GetFolderPath('Desktop')
New-Item -ItemType Directory -Path $desktop -Force | Out-Null
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut((Join-Path $desktop '갤럭시 관제소.lnk'))
$windowlessPython = Join-Path $env:LOCALAPPDATA 'GRP\env\Scripts\pythonw.exe'
if (Test-Path -LiteralPath $windowlessPython) {
    $shortcut.TargetPath = $windowlessPython
    $shortcut.Arguments = '"' + (Join-Path $appFolder 'launch.py') + '"'
} else {
    $shortcut.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
    $shortcut.Arguments = '"' + (Join-Path (Split-Path $appFolder -Parent) '갤럭시 관제소 실행.vbs') + '"'
}
$shortcut.WorkingDirectory = $appFolder
$shortcut.IconLocation = (Join-Path $appFolder 'assets\robocrew.ico') + ',0'
$shortcut.Description = '갤럭시 관제소 · 예약현황과 갤럭시 무전기'
$shortcut.Save()
# Remove only the previous shortcut created for this exact app folder.
$oldPath = Join-Path $desktop 'Galaxy Robot Park.lnk'
if (Test-Path -LiteralPath $oldPath) {
    $oldShortcut = $shell.CreateShortcut($oldPath)
    if ($oldShortcut.TargetPath -eq (Join-Path $appFolder 'Start.bat')) {
        Remove-Item -LiteralPath $oldPath
    }
}
