"""갤럭시 예약현황 — Qt 데스크톱 화면."""
import calendar, csv, json, queue, sys, threading, time
from pathlib import Path
from datetime import date
from PySide6.QtCore import Qt, QDate, QUrl, QSize, QTimer, QLocale, QRectF, QPropertyAnimation, QEasingCurve
from PySide6.QtGui import QColor, QIcon, QDesktopServices, QPixmap, QFontDatabase, QFont, QPainter, QPen, QLinearGradient, QRadialGradient
from PySide6.QtWidgets import (QApplication, QLayout, QMainWindow, QWidget, QFrame, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QCalendarWidget, QDateEdit, QSpinBox, QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView, QProgressBar, QFileDialog, QMessageBox, QStackedWidget, QScrollArea, QSizePolicy, QDialog, QGraphicsOpacityEffect, QLineEdit, QPlainTextEdit)
from core import today
from battle import CrewBattle
from professor import PixelProfessor, countdown_message
import updater
import socket
from scanner import Scanner
from history import History
from mobile import Mobile
from cloud_chat import CloudChat as Chat
ROOT=Path(__file__).resolve().parent
INK='#f2f6ff';MUTED='#a4b1ca';ACCENT='#68efc2'
STYLE='''
QWidget {font-family:"Galmuri11",sans-serif;font-size:12px;color:#eef4ff;}
QMainWindow, QWidget#workspace, QWidget#reservationContent, QScrollArea#reservationScroll, QScrollArea#sidebarScroll {background:#0b1020;}
QFrame#sidebar {background:#12182c;border:0;}
QLabel {background:transparent;}
QLabel#muted {color:#8999c5;}
QLabel#sideMuted {color:#8e9db7;}
QLabel#sideTitle {color:#f4f7ff;font-size:14px;font-weight:600;}
QLabel#eyebrow {font-family:"Galmuri9";color:#798ee9;font-size:10px;font-weight:700;letter-spacing:2px;}
QLabel#title {font-size:24px;font-weight:700;color:#eef4ff;}
QLabel#badge {background:#102045;color:#7df7de;border-radius:2px;padding:5px 10px;font-size:12px;}
QLabel#new {background:#421127;color:#ff647d;border-radius:2px;padding:3px 7px;font-size:10px;font-weight:700;}
QFrame#card {background:#151d32;border:1px solid #394767;border-radius:3px;}
QPushButton {background:#202b46;border:1px solid #667cac;border-radius:2px;padding:10px 17px;font-weight:600;}
QPushButton:hover {background:#17254e;border-color:#638aff;}
QPushButton:pressed {background:#20356d;}
QPushButton:disabled {color:#68728d;background:#11172b;border-color:#28324f;}
QPushButton#primary {background:#ffe15a;border:1px solid #ffe15a;color:#080b1c;}
QPushButton#primary:hover {background:#ffed96;}
QPushButton#primary:disabled {background:#827647;border-color:#827647;}
QPushButton#nav {text-align:left;background:transparent;border:0;color:#a8b6cf;padding:12px 15px;}
QPushButton#nav:checked {background:#173c40;color:#85f6d2;border:1px solid #48bda5;}
QPushButton#nav:hover {background:#142148;}
QPushButton#sideButton {background:#101934;border:1px solid #304fab;color:#d6e2f5;padding:8px 10px;}
QPushButton#sideButton:checked {background:#142453;border-color:#638aff;color:#ffe15a;}
QPushButton#sideButton:hover {background:#1b2a54;}
QCheckBox {spacing:8px;color:#a8b6cf;font-size:12px;}
QCheckBox::indicator {width:15px;height:15px;border:1px solid #61718b;border-radius:4px;background:#0e1430;}
QCheckBox::indicator:checked {background:#65f5cf;border:1px solid #65f5cf;}
QSpinBox {background:#101934;border:1px solid #304fab;border-radius:2px;color:#e7f0ff;padding:6px 9px;}
QSpinBox::up-button,QSpinBox::down-button {width:17px;}
QCalendarWidget {background:#0d1531;}
QCalendarWidget QAbstractItemView {background:#0d1531;color:#cfdaec;selection-background-color:#ffe15a;selection-color:#080b1c;font-size:12px;border:0;outline:0;}
QCalendarWidget QWidget#qt_calendar_navigationbar {background:#0d1531;}
QCalendarWidget QToolButton {background:transparent;color:#e4edf9;border:0;padding:5px;font-size:12px;}
QCalendarWidget QSpinBox {background:#142453;color:white;}
QTableWidget {background:#151d32;alternate-background-color:#19243b;border:0;gridline-color:#1a2850;selection-background-color:#152b58;selection-color:#eef4ff;outline:0;font-size:12px;}
QTableWidget::item {padding:12px 13px;border-bottom:1px solid #2d3a54;}
QHeaderView::section {background:#23304b;border:0;border-bottom:2px solid #6985bd;color:#d7e5ff;padding:14px 12px;font-size:12px;font-weight:600;}
QLineEdit,QPlainTextEdit {background:#111c2c;color:#eef4ff;border:1px solid #3c6f77;padding:10px;selection-background-color:#2848b8;}
QScrollBar:vertical {background:transparent;width:7px;margin:2px;}
QScrollBar::handle:vertical {background:#3553c4;border-radius:3px;min-height:30px;}
QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical {height:0;}
QScrollBar::add-page:vertical,QScrollBar::sub-page:vertical {background:transparent;}
QProgressBar {background:#0c1734;border:0;border-radius:3px;max-height:5px;}
QProgressBar::chunk {background:#65f5cf;border-radius:3px;}
'''

def load_pixel_fonts():
    for name in ('Galmuri11.ttf','Galmuri11-Bold.ttf','Galmuri9.ttf'):
        path=ROOT/'assets'/'fonts'/name
        if QFontDatabase.addApplicationFont(str(path))<0:
            raise RuntimeError('픽셀 폰트를 불러오지 못했습니다. assets 폴더를 포함해 압축을 다시 풀어주세요: '+name)

def pixel_font(size=12,bold=False):
    f=QFont('Galmuri11');f.setPixelSize(size);f.setBold(bold);f.setStyleStrategy(QFont.StyleStrategy.NoAntialias);return f

def label(text='',name=None,size=None,bold=False,color=None):
    w=QLabel(text)
    if name:w.setObjectName(name)
    if size or color:w.setStyleSheet((f'font-size:{10 if size<=11 else 12 if size<18 else 24 if size<30 else 36}px;font-family:"{"Galmuri9" if size<=11 else "Galmuri11"}";' if size else '')+('font-weight:700;' if bold else '')+(f'color:{color};' if color else ''))
    return w

def button(text,fn,name=None):
    b=QPushButton(text)
    if name:b.setObjectName(name)
    b.setMinimumHeight(38);b.setSizePolicy(QSizePolicy.Policy.Minimum,QSizePolicy.Policy.Fixed);b.setCursor(Qt.CursorShape.PointingHandCursor);b.clicked.connect(fn);return b

def card():
    w=QFrame();w.setObjectName('card');return w

class OrbitLogo(QWidget):
    def __init__(self):
        super().__init__();self.setFixedSize(48,48)
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing)
        g=QLinearGradient(0,0,48,48);g.setColorAt(0,QColor('#3a6c78'));g.setColorAt(1,QColor('#303353'))
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(g);p.drawRoundedRect(QRectF(0,0,48,48),14,14)
        p.setBrush(QColor('#0c1428'));p.drawEllipse(QRectF(10,35,30,7))
        metal=QLinearGradient(10,12,37,36);metal.setColorAt(0,QColor('#ffffff'));metal.setColorAt(.35,QColor('#d8e6f2'));metal.setColorAt(.7,QColor('#859bb7'));metal.setColorAt(1,QColor('#ebf5ff'))
        p.setPen(QPen(QColor('#c6d9ed'),.7));p.setBrush(metal);p.drawRoundedRect(QRectF(10,12,28,25),10,10)
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#182a43'));p.drawRoundedRect(QRectF(14,19,20,10),5,5)
        p.setBrush(QColor('#81f9e5'));p.drawEllipse(QRectF(18,22,3,3));p.drawEllipse(QRectF(27,22,3,3))
        p.setPen(QPen(QColor('#84e5d3'),1.4));p.drawLine(24,7,24,12)
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#b9fff0'));p.drawEllipse(QRectF(22,5,4,4))
        p.end()

class ArcadeWorkspace(QWidget):
    def paintEvent(self,event):
        p=QPainter(self);p.fillRect(self.rect(),QColor('#050611'))
        for i in range(100):
            x=(i*193+17)%max(1,self.width());y=(i*97+29)%max(1,self.height())
            p.fillRect(x,y,2 if i%8==0 else 1,2 if i%8==0 else 1,QColor('#2d407a' if i%3 else '#5a568c'))
        p.end()

class ArcadeBuddy(QWidget):
    """Small native pixel animation; no images or network requests."""
    ROBOT=('000011110000','000010010000','001111111100','011111111110','011001100110','011001100110','011111111110','001110011100','000111111000','001111111100','011111111110','011001100110','000110011000')
    ALIEN=('001000100','000101000','001111100','011010110','111111111','101111101','101000101','000101000')
    def __init__(self,busy,parent=None):
        super().__init__(parent);self.busy=busy;self.frame=0;self.greeting=0;self.setFixedHeight(136);self.setCursor(Qt.CursorShape.PointingHandCursor);self.setToolTip('픽셀 로봇을 클릭해 보세요')
        self.timer=QTimer(self);self.timer.timeout.connect(self.step);self.timer.start(450)
    def step(self):
        self.frame+=1
        if self.greeting:self.greeting-=1
        self.update()
    def mousePressEvent(self,event):
        self.greeting=8;self.update()
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing,False);scale=min(self.width()/196,self.height()/136);p.translate((self.width()-196*scale)/2,0);p.scale(scale,scale);p.setPen(Qt.PenStyle.NoPen)
        busy=self.busy();bob=2 if self.frame%2 else 0
        p.setBrush(QColor('#112147'));p.drawRect(12,91,170,2)
        p.setBrush(QColor('#1c2e61'));p.drawRect(70,83,60,4)
        # Robot body, antenna and shadow use integer aligned pixel blocks.
        for y,line in enumerate(self.ROBOT):
            for x,c in enumerate(line):
                if c=='1':
                    p.setBrush(QColor('#3f60dc' if y>8 else '#76d9ff'));p.drawRect(76+x*4,23+y*4+bob,4,4)
        p.setBrush(QColor('#ffe15a'));p.drawRect(92,23+bob,8,4)
        eye=QColor('#ffe15a' if busy or self.greeting else '#080b1c');p.setBrush(eye);p.drawRect(88,39+bob,8,4 if self.frame%9 else 2);p.drawRect(104,39+bob,8,4 if self.frame%9 else 2)
        p.setBrush(QColor('#76d9ff'));p.drawRect(124,55+bob,8,4);p.drawRect(132,47+bob-(4 if self.frame%2 else 0),4,12)
        # Two arcade companions float beside the robot.
        for offset,color in [(20,'#ff80b5'),(151,'#65f5cf')]:
            for y,line in enumerate(self.ALIEN):
                for x,c in enumerate(line):
                    if c=='1':p.setBrush(QColor(color));p.drawRect(offset+x*2,49+y*2-bob,2,2)
        p.setPen(QColor('#889bc9'));p.setFont(pixel_font());p.drawText(QRectF(0,0,self.width(),17),Qt.AlignmentFlag.AlignCenter,'ROBO CREW  /  로보 크루')
        text='삐빅! 만나서 반가워요' if self.greeting else '예약을 확인하고 있어요' if busy else '오늘도 준비 완료!'
        p.setPen(QColor('#ffe15a' if self.greeting else '#a8b6cf'));p.drawText(QRectF(0,102,self.width(),22),Qt.AlignmentFlag.AlignCenter,text);p.end()

class App(QMainWindow):
    def __init__(self,services=True):
        super().__init__();self.services=services;self.setWindowIcon(QIcon(str(ROOT/'assets'/'robocrew.ico')));self.setWindowTitle('갤럭시 관제소 · v8.38');self.resize(1360,860);self.setMinimumSize(1080,760)
        self.events=queue.Queue();self.jobs=queue.Queue();self.stop=threading.Event();self.busy=False;self.view_month=None;self.batch_info='';self.rows=[];self.known_slots={};self.scanned=0;self.started=0;self.closing=False
        self.history=History(ROOT/'reservation_history.json')
        self.mobile=Mobile(self.events);self.mobile_url='';self.chat=Chat(self.events)
        if services:
            try:self.mobile_url=self.mobile.start()
            except OSError:pass
        central=ArcadeWorkspace();central.setObjectName('workspace');self.setCentralWidget(central)
        base=QHBoxLayout(central);base.setContentsMargins(0,0,0,0);base.setSpacing(0)
        side=QFrame();side.setObjectName('sidebar');side.setMinimumWidth(220);self.sidebar_scroll=QScrollArea();self.sidebar_scroll.setObjectName('sidebarScroll');self.sidebar_scroll.setFixedWidth(234);self.sidebar_scroll.setWidgetResizable(True);self.sidebar_scroll.setFrameShape(QFrame.Shape.NoFrame);self.sidebar_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff);self.sidebar_scroll.setWidget(side);base.addWidget(self.sidebar_scroll)
        sl=QVBoxLayout(side);sl.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize);sl.setContentsMargins(12,18,12,16);sl.setSpacing(8)
        brand=QHBoxLayout();logo=QPushButton();logo.setIcon(QIcon(QPixmap(str(ROOT/'assets'/'galaxy_logo_arcade.png'))));logo.setIconSize(QSize(190,66));logo.setFixedSize(196,74);logo.setStyleSheet('QPushButton {background:transparent;border:0;padding:0;}');logo.setCursor(Qt.CursorShape.PointingHandCursor);logo.setToolTip('갤럭시로봇파크 네이버 페이지 열기');logo.clicked.connect(lambda:QDesktopServices.openUrl(QUrl('https://m.place.naver.com/place/1378952275/home')));self.logo=logo;self.logo_effect=QGraphicsOpacityEffect(logo);logo.setGraphicsEffect(self.logo_effect);self.logo_glow=QPropertyAnimation(self.logo_effect,b'opacity',self);self.logo_glow.setDuration(1800);self.logo_glow.setStartValue(1.0);self.logo_glow.setKeyValueAt(.5,.4);self.logo_glow.setEndValue(1.0);self.logo_glow.setEasingCurve(QEasingCurve.Type.InOutSine);self.logo_glow.setLoopCount(-1);self.logo_glow.start();brand.addWidget(logo);brand.addStretch();sl.addLayout(brand)
        sl.addSpacing(18);sl.addWidget(label('●  GALAXY CONTROL','eyebrow'))
        self.nav_res=button('예약현황',lambda:self.navigate(0),'nav');self.nav_res.setCheckable(True);self.nav_res.setChecked(True);sl.addWidget(self.nav_res)
        self.venue_buttons=[]
        for title,place,color in [('WHAT A BREAD','2046089192','#ffc68b'),('AURORA BISTRO','2055475522','#c6a2ff'),('AURORA LOUNGE','2093806444','#78d5ff')]:
            url='https://map.naver.com/p/entry/place/'+place
            link=button(title,lambda checked=False,address=url:QDesktopServices.openUrl(QUrl(address)))
            link.setFont(pixel_font(12,True));link.setMinimumHeight(36);link.setToolTip('네이버 지도 · '+title)
            link.setStyleSheet('QPushButton {text-align:left;background:#18223a;border:1px solid '+color+';color:'+color+';padding:8px 12px;} QPushButton:hover {background:#293859;}')
            self.venue_buttons.append(link);sl.addWidget(link)
        sl.addSpacing(12);self.professor=PixelProfessor();sl.addWidget(self.professor)
        self.cal=QCalendarWidget();self.cal.setLocale(QLocale('ko_KR'));self.cal.setVerticalHeaderFormat(QCalendarWidget.VerticalHeaderFormat.NoVerticalHeader);self.cal.setHorizontalHeaderFormat(QCalendarWidget.HorizontalHeaderFormat.SingleLetterDayNames);self.cal.setFirstDayOfWeek(Qt.DayOfWeek.Monday);self.cal.setFixedHeight(206)
        self.cal.setSelectedDate(QDate.fromString(today(),'yyyy-MM-dd'));self.cal.clicked.connect(self.choose_day);self.calendar_popup=QDialog(self);self.calendar_popup.setWindowFlags(Qt.WindowType.Popup);self.calendar_popup.setWindowTitle('조회 날짜 선택');cl=QVBoxLayout(self.calendar_popup);cl.addWidget(self.cal);self.cal.clicked.connect(lambda _:self.calendar_popup.accept())
        # Date selection lives in the reservation toolbar.
        self.cap=QSpinBox(self);self.cap.setRange(1,1000);self.cap.setValue(200);self.cap.hide()
        try:self.cap.setValue(int(json.loads((ROOT/'settings.json').read_text(encoding='utf-8'))['capacity']))
        except Exception:pass
        self.auto=QCheckBox(self);self.auto.hide()
        self.follow=QCheckBox(self);self.follow.hide()
        self.inline_chat=card();self.inline_chat.setStyleSheet('QFrame#card {background:#122b31;border:1px solid #438e91;border-top:3px solid #65dfce;}');self.inline_chat.setMinimumHeight(270);ic=QVBoxLayout(self.inline_chat);ic.setContentsMargins(8,8,8,8);ic.setSpacing(6);chh=QHBoxLayout();chh.addWidget(label('● 갤럭시 무전기',size=12,bold=True,color='#82f0d7'));chh.addStretch();self.chat_mode=label('OFF','badge');chh.addWidget(self.chat_mode);chh.addWidget(button('설정',lambda:self.chat_dialog.exec(),'sideButton'));ic.addLayout(chh);self.chat_log=QPlainTextEdit();self.chat_log.setReadOnly(True);self.chat_log.setMaximumBlockCount(500);self.chat_log.setMinimumHeight(125);self.chat_log.setPlaceholderText('팀 무전에 자동 연결합니다.');ic.addWidget(self.chat_log,1);self.chat_text=QLineEdit();self.chat_text.setMinimumHeight(40);self.chat_text.setMaxLength(500);self.chat_text.setPlaceholderText('메시지 입력 · Enter');self.chat_text.returnPressed.connect(self.send_chat);ic.addWidget(self.chat_text);self.chat_send=button('전송',self.send_chat,'sideButton');self.chat_send.setEnabled(False);ic.addWidget(self.chat_send);sl.addWidget(self.inline_chat,1);sl.addWidget(button('업데이트 설정',self.update_settings,'sideButton'));sl.addWidget(label('GALAXY  /  DESKTOP  8.38',size=9,color='#60718d'))
        self.stack=QStackedWidget();base.addWidget(self.stack,1)
        self.res_page=QWidget();self.res_page.setObjectName("reservationContent");self.res_scroll=QScrollArea();self.res_scroll.setObjectName("reservationScroll");self.res_scroll.setWidgetResizable(True);self.res_scroll.setFrameShape(QFrame.Shape.NoFrame);self.res_scroll.setWidget(self.res_page);self.stack.addWidget(self.res_scroll);rl=QVBoxLayout(self.res_page);rl.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize);rl.setContentsMargins(32,29,32,22);rl.setSpacing(16)
        topline=QHBoxLayout();tit=QVBoxLayout();tit.setSpacing(7);tit.addWidget(label('◆  RESERVATION BOARD  /  예약현황',size=11,bold=True,color='#78dcff'));self.date_title=label('', 'title');tit.addWidget(self.date_title);self.date_sub=label('공연별 예약 추정 인원을 한눈에 확인하세요.','muted');tit.addWidget(self.date_sub);topline.addLayout(tit);topline.addStretch()
        rl.addLayout(topline)
        self.date_controls=QWidget();datebar=QHBoxLayout(self.date_controls);datebar.setContentsMargins(0,0,0,0);datebar.setSpacing(8)
        datebar.addWidget(label('조회 날짜',size=12,bold=True))
        self.date_picker=button('',self.open_date_calendar);self.date_picker.setMinimumWidth(235);self.date_picker.setStyleSheet('QPushButton {background:#101934;border:1px solid #436aff;padding:8px;color:#ffe15a;} QPushButton:hover {background:#1b2a54;}');datebar.addWidget(self.date_picker)
        self.all_button=button('예약 확인',lambda:self.start(),'primary');datebar.addWidget(self.all_button);datebar.addWidget(button('오늘',self.select_today));datebar.addStretch();rl.addWidget(self.date_controls)
        self.buddy=CrewBattle(lambda:self.busy,self);rl.addWidget(self.buddy)
        statrow=QHBoxLayout();statrow.setSpacing(16);self.statvalues=[]
        for title,hint,color in [('예약 추정 합계','표시된 회차 기준','#68efc2'),('표시된 공연','선택한 날짜의 공연','#c6a2ff'),('선택 가능 합계','예약 화면의 선택 상한','#78d5ff')]:
            w=card();w.setStyleSheet('QFrame#card {background:'+{'#68efc2':'#113331','#c6a2ff':'#2d2144','#78d5ff':'#162f45'}[color]+';border:1px solid '+color+';border-top:4px solid '+color+';}');l=QVBoxLayout(w);l.setContentsMargins(23,12,23,10);l.setSpacing(5);l.addWidget(label(title,size=13,bold=True,color=color));value=label('—',size=36,bold=True,color=color);l.addWidget(value);l.addWidget(label(hint,size=10,color='#95a0b3'));self.statvalues.append(value);statrow.addWidget(w,1)
        rl.addLayout(statrow)
        tablecard=card();tl=QVBoxLayout(tablecard);tl.setContentsMargins(0,0,0,0);tl.setSpacing(0)
        section=QHBoxLayout();section.setContentsMargins(22,11,18,11);section.addWidget(label('공연별 예약현황',size=16,bold=True,color='#c6a2ff'));self.record_badge=label('확인 전','badge');section.addWidget(self.record_badge);section.addStretch();self.refresh_button=button('새로고침',lambda:self.start());self.refresh_button.setStyleSheet('QPushButton {background:#193b40;border:1px solid #50cbb2;color:#8df8d5;padding:10px 17px;} QPushButton:hover {background:#24545a;}');section.addWidget(self.refresh_button);tl.addLayout(section)
        self.table=QTableWidget(0,7);self.table.setMinimumHeight(230);self.table.setHorizontalHeaderLabels(['날짜','공연 시간','예약 추정','직전 대비','선택 가능','혼잡도','조회 상태']);self.table.setAlternatingRowColors(True);self.table.setShowGrid(False);self.table.verticalHeader().hide();self.table.verticalHeader().setDefaultSectionSize(60);self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows);self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection);self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers);self.table.setFocusPolicy(Qt.FocusPolicy.NoFocus);self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents);self.table.horizontalHeader().setMinimumSectionSize(90);self.table.setTextElideMode(Qt.TextElideMode.ElideNone);self.table.horizontalHeader().setStretchLastSection(True);self.table.cellDoubleClicked.connect(lambda *_:self.refresh_selected());tl.addWidget(self.table,1)
        self.empty=label('아직 표시할 예약 기록이 없어요. 예약 확인을 눌러 주세요.',size=15,color='#93a0b5');self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter);self.empty.setMinimumHeight(110);tl.addWidget(self.empty)
        self.summary=label('','muted');self.summary.setContentsMargins(22,12,22,12);tl.addWidget(self.summary);rl.addWidget(tablecard,1)
        foot=card();fl=QVBoxLayout(foot);fl.setContentsMargins(18,13,18,12);fl.setSpacing(9);line=QHBoxLayout();self.status=label('날짜를 선택하고 예약 확인을 누르세요.');self.status.setWordWrap(True);line.addWidget(self.status,1);self.elapsed=label('','muted');line.addWidget(self.elapsed);self.cancel_button=button('중지',self.cancel);self.cancel_button.setVisible(False);line.addWidget(self.cancel_button);fl.addLayout(line);self.progress=QProgressBar();self.progress.setRange(0,100);self.progress.setTextVisible(False);fl.addWidget(self.progress);rl.addWidget(foot)
        bottom=label('정원 − 선택 가능 수량 = 예약 추정  ·  회차가 사라져도 마지막 기록을 유지합니다.',size=10,color='#8a96aa');footer=QHBoxLayout();bottom.setWordWrap(True);footer.addWidget(bottom,1);footer.addWidget(label('개발자: 김성규',size=12,color='#a8b6cf'));rl.addLayout(footer)
        self.chat_dialog=QDialog(self);self.chat_dialog.setWindowTitle('갤럭시 무전기 연결');self.chat_dialog.setMinimumWidth(620);ch=QVBoxLayout(self.chat_dialog)
        ch.addWidget(label('갤럭시 무전기','title'));info=label('다른 지역에서도 같은 방 코드로 연결됩니다. 계정·카드 등록 없이 무료 중계를 사용하며, 한도에 걸리면 연결 또는 전송이 제한됩니다.','muted');info.setWordWrap(True);ch.addWidget(info)
        self.chat_name=QLineEdit('직원-'+socket.gethostname()[:12]);self.chat_name.setMaxLength(24);ch.addWidget(label('닉네임'));ch.addWidget(self.chat_name);self.chat_address=QLineEdit();self.chat_address.setPlaceholderText('GRP-로 시작하는 비밀 방 코드');ch.addWidget(label('방 코드 · 직원끼리만 공유하세요'));ch.addWidget(self.chat_address)
        cr=QHBoxLayout();cr.addWidget(button('새 방 만들기',self.host_chat,'primary'));cr.addWidget(button('방 코드 복사',self.copy_chat));cr.addWidget(button('연결',self.join_chat));cr.addWidget(button('연결 종료',self.leave_chat));ch.addLayout(cr)
        self.chat_state=label('아직 연결되지 않았습니다.','muted');self.chat_state.setWordWrap(True);ch.addWidget(self.chat_state)
        note=label('내용은 암호화되어 중계됩니다. 방 코드는 접속·복호화 열쇠입니다. 서버의 임시 보관은 기본 12시간이며, 대화는 앱의 파일에 저장하지 않습니다.','muted');note.setWordWrap(True);ch.addWidget(note)
        self.res_timer=QTimer(self);self.res_timer.setSingleShot(True);self.res_timer.timeout.connect(lambda:self.start(automatic=True))
        self.poll_timer=QTimer(self);self.poll_timer.timeout.connect(self.poll);self.poll_timer.start(100)
        self.clock=QTimer(self);self.clock.timeout.connect(self.tick);self.clock.start(500)
        self.render()
        self.restore_chat()
        self.update_status='업데이트 확인 대기'
        if services:QTimer.singleShot(1000,self.check_update)
        if services and self.chat_auto:QTimer.singleShot(250,self.join_chat)
        if services:threading.Thread(target=self.worker,daemon=True).start()

    def check_update(self):
        if getattr(self,'update_checking',False):return
        self.update_checking=True;self.update_status='업데이트 확인 중…'
        def work():
            try:result=updater.stage(ROOT)
            except Exception as error:result='업데이트 확인 실패 · 현재 버전 유지: '+str(error)
            self.events.put(('update_status',result))
        threading.Thread(target=work,daemon=True).start()
    def update_settings(self):
        dialog=QDialog(self);dialog.setWindowTitle('자동 업데이트');dialog.setMinimumWidth(560);layout=QVBoxLayout(dialog)
        layout.addWidget(label('앱을 켜면 새 버전을 확인하고, 다음 실행부터 적용합니다.'))
        layout.addWidget(label('업데이트 배포 주소 (HTTPS)'))
        address=QLineEdit(updater.config(ROOT).get('manifest_url',''));address.setPlaceholderText('배포 주소를 연결해야 자동 업데이트가 시작됩니다.');layout.addWidget(address)
        state=label(getattr(self,'update_status',''));state.setWordWrap(True);layout.addWidget(state)
        def save():
            try:updater.save_source(address.text().strip())
            except Exception as error:state.setText(str(error));return
            self.check_update();dialog.accept()
        layout.addWidget(button('저장하고 확인',save,'primary'));dialog.exec()
    def day(self):return self.cal.selectedDate().toString('yyyy-MM-dd')
    def open_date_calendar(self):
        if not self.busy:
            self.calendar_popup.adjustSize();self.calendar_popup.move(self.date_picker.mapToGlobal(self.date_picker.rect().bottomLeft()));self.calendar_popup.show()
    def shift_day(self,offset):
        if not self.busy:self.pick_day(self.cal.selectedDate().addDays(offset))
    def pick_day(self,qday):
        if self.busy:return
        self.cal.setSelectedDate(qday);self.choose_day(qday)
    def choose_day(self,qday):
        if self.busy:return
        self.view_month=None;self.follow.setChecked(False);self.load_history()
    def select_today(self):
        if self.busy:return
        self.view_month=None;self.cal.setSelectedDate(QDate.fromString(today(),'yyyy-MM-dd'));self.follow.setChecked(True);self.load_history()
    def load_history(self):
        self.rows=[dict(r,cached=True,delta=None,status='저장된 기록 · 새로 확인 필요') for r in self.history.rows(self.day())];self.status.setText('저장된 기록을 표시합니다. 선택한 날짜의 저장 기록입니다. 예약 확인을 눌러 갱신하세요.');self.render()
    def navigate(self,index):
        self.stack.setCurrentIndex(0);self.nav_res.setChecked(True)
    def render(self):
        d=date.fromisoformat(self.day());self.date_title.setText(f'{d.month}월 {d.day}일, '+('월요일','화요일','수요일','목요일','금요일','토요일','일요일')[d.weekday()]);self.date_sub.setText(f'{d.year}년 · 갤럭시 로봇파크 공연 예약현황')
        selected=self.table.currentRow();chosen=self.table.item(selected,0).data(Qt.ItemDataRole.UserRole) if selected>=0 and self.table.item(selected,0) else None
        def key(r):
            p,t=r['time'].split();h,m=map(int,t.split(':'));return (r['date'],(h%12+(12 if p=='오후' else 0))*60+m)
        
        self.date_controls.setEnabled(not self.busy);self.date_picker.setText(self.cal.selectedDate().toString('yyyy년 M월 d일')+'  ▾');self.all_button.setText('예약 확인')
        if self.view_month:self.date_title.setText(f'{self.view_month[0]}년 {self.view_month[1]}월 전체');self.date_sub.setText(self.batch_info or '지난 날짜는 저장 기록 · 오늘 이후는 순서대로 조회')
        self.rows.sort(key=key);valid=[r for r in self.rows if r['booked'] is not None]
        self.statvalues[0].setText(f"{sum(r['booked'] for r in valid):,}석" if valid else '—');self.statvalues[1].setText(f'{len(self.rows)}회');self.statvalues[2].setText(f"{sum(r['selectable'] for r in valid):,}석" if valid else '—')
        self.record_badge.setText(f'{len(self.rows)}회차' if self.rows else '확인 전');self.table.setRowCount(len(self.rows));self.table.setVisible(bool(self.rows));self.empty.setVisible(not self.rows)
        for i,r in enumerate(self.rows):
            delta=r.get('delta');change='—' if delta is None else f'+{delta}' if delta>0 else str(delta);booked=r['booked'];message='—' if booked is None else '내실을 다지자!' if booked<80 else '해낼 수 있다!' if booked<160 else '전력으로 달리자!';message_color=MUTED if booked is None else '#65f5a6' if booked<80 else '#ffe15a' if booked<160 else '#ff8093';state='이전 기록' if r.get('cached') else '확인 완료' if r['booked'] is not None else '확인 실패'
            for j,text in enumerate((r['date'][5:].replace('-','/'),r['time'],str(r['booked'])+'석' if r['booked'] is not None else '—',change,str(r['selectable'])+'석' if r['selectable'] is not None else '—',message,state)):
                item=QTableWidgetItem(text);item.setTextAlignment(Qt.AlignmentFlag.AlignCenter);item.setToolTip(r['status']+'\n확인: '+r['checked']);item.setForeground(QColor(message_color if j==5 else MUTED if r.get('cached') else ACCENT if j==2 else '#c6a2ff' if j==1 else '#78d5ff' if j==4 else '#ffac82' if j==6 and r['booked'] is None else '#82edd5' if j==6 else INK))
                if j in (1,2,5):f=pixel_font(24 if j==2 else 12,True);item.setFont(f)
                self.table.setItem(i,j,item)
            self.table.item(i,0).setData(Qt.ItemDataRole.UserRole,(r['date'],r['time']))
            if chosen==(r['date'],r['time']):self.table.selectRow(i)
        stale=sum(bool(r.get('cached')) for r in valid);self.summary.setText(f'기록 {len(valid)}/{len(self.rows)}회차'+(f'  ·  이전 기록 {stale}회차 포함 — 행에 마우스를 올려 확인 시각을 확인하세요.' if stale else '  ·  회차별 확인 시각이 다를 수 있습니다.'))
        self.table.resizeColumnsToContents()
        for column, minimum in ((1,120),(2,130),(3,100),(4,115),(5,175),(6,115)):
            self.table.setColumnWidth(column,max(minimum,self.table.columnWidth(column)))
        self.publish()
    def publish(self):self.mobile.update(rows=[dict(r) for r in self.rows],date=self.day(),status=self.status.text(),summary=self.summary.text(),busy=self.busy)
    def start(self,automatic=False,target=None,day=None):
        if self.busy:return
        if self.view_month and target is None:self.daily_view()
        if automatic and self.follow.isChecked():self.cal.setSelectedDate(QDate.fromString(today(),'yyyy-MM-dd'));self.load_history()
        if (day or self.day())<today():self.status.setText('지난 날짜는 저장된 기록만 볼 수 있습니다.');self.publish();return
        try:(ROOT/'settings.json').write_text(json.dumps({'capacity':self.cap.value()}),encoding='utf-8')
        except OSError as e:QMessageBox.warning(self,'설정 저장 실패',str(e));return
        self.res_timer.stop();self.busy=True;self.started=time.monotonic();self.scanned=0;self.stop.clear();self.cal.setEnabled(False);self.all_button.setEnabled(False);self.refresh_button.setEnabled(False);self.cancel_button.show();self.progress.setValue(0);self.status.setText('삐비빅....실시간 레이더 감지중..')
        for r in self.rows:
            if r['date']==(day or self.day()) and (not target or target==r['time']):r.update(cached=True,delta=None,status='이전 기록 · 갱신 중')
        self.render();self.jobs.put((day or self.day(),self.cap.value(),target))
    def refresh_selected(self):
        row=self.table.currentRow()
        if row<0:QMessageBox.information(self,'회차 선택','표에서 회차 하나를 선택해 주세요.');return
        day,slot=self.table.item(row,0).data(Qt.ItemDataRole.UserRole);self.start(target=slot,day=day)
    def daily_view(self):
        if self.busy:return
        self.view_month=None;self.load_history()
    def start_month(self,offset):
        if self.busy:return
        d=date.fromisoformat(today());year=d.year+(1 if offset and d.month==12 else 0);month=(d.month%12+1) if offset else d.month
        self.view_month=(year,month);self.rows=[]
        days=[date(year,month,n).isoformat() for n in range(1,calendar.monthrange(year,month)[1]+1)]
        for day in days:self.rows.extend(dict(r,cached=True,delta=None,status='保存 기록 · 새로 확인 필요'.replace('保存','저장')) for r in self.history.rows(day))
        fetch=[day for day in days if day>=today()];self.auto.setChecked(False);self.batch_info=f'{len(fetch)}일 순서대로 확인 · 지난 날짜는 저장 기록';self.busy=True;self.started=time.monotonic();self.scanned=0;self.stop.clear();self.cal.setEnabled(False);self.all_button.setEnabled(False);self.refresh_button.setEnabled(False);self.cancel_button.show();self.progress.setValue(0);self.render();self.jobs.put((fetch,self.cap.value(),None))
    def worker(self):
        scanner=Scanner()
        try:
            while True:
                job=self.jobs.get()
                if job is None:break
                try:
                    if not isinstance(job[0],list):
                        scanner.scan(*job[:2],self.stop,lambda k,v:self.events.put((k,v)),target=job[2]);self.events.put(('done',None));continue
                    days=job[0];failures=0
                    for index,day in enumerate(days):
                        if self.stop.is_set():raise RuntimeError('월간 확인을 중지했습니다.')
                        self.events.put(('batch_day',f'{day} · {index+1}/{len(days)}일 확인 중'))
                        def emit(kind,value):
                            if kind=='progress':value=dict(value,value=100*(index+value['value']/100)/len(days),text=day+' · '+value['text'])
                            if kind=='status':value=day+' · '+value
                            self.events.put((kind,value))
                        try:scanner.scan(day,job[1],self.stop,emit)
                        except Exception as e:
                            if self.stop.is_set() or '자동 확인을 중단' in str(e):raise
                            failures+=1;self.events.put(('status',day+' 조회 실패 · 이전 기록 유지: '+str(e)))
                        self.events.put(('batch_day',f'{index+1}/{len(days)}일 점검 · 날짜 조회 실패 {failures}일'));self.events.put(('progress',{'value':100*(index+1)/len(days),'text':day+' 날짜 점검 완료'}))
                        if index+1<len(days) and self.stop.wait(5):raise RuntimeError('월간 확인을 중지했습니다.')
                    self.events.put(('done',f'월간 점검 완료 · {len(days)}일 · 날짜 조회 실패 {failures}일 · 회차가 없는 날짜는 예약 0명으로 계산하지 않습니다.'))
                except Exception as e:self.events.put(('error',str(e)))
        finally:scanner.close()
    def cancel(self):self.stop.set();self.auto.setChecked(False);self.status.setText('중지 요청 중…' if self.busy else '자동 확인을 해제했습니다.')
    def schedule(self,*_):
        self.res_timer.stop()
        if self.auto.isChecked() and not self.busy:self.res_timer.start(600000)
    def poll(self):
        try:
            while True:
                kind,value=self.events.get_nowait()
                if kind=='update_status':
                    self.update_checking=False;self.update_status=value;self.status.setToolTip(value)
                    if '준비 완료' in value:self.status.setText(value)
                elif kind=='status':self.status.setText('삐비빅....실시간 레이더 감지중..' if self.busy else value)
                elif kind=='progress':self.progress.setValue(int(value['value']));self.status.setText('삐비빅....실시간 레이더 감지중..')
                elif kind=='slots':
                    self.known_slots[value['date']]=list(value['slots'])
                    for r in self.rows:
                        if r['date']==value['date'] and r['time'] not in value['slots']:r.update(cached=True,delta=None,status='현재 목록에 없음 · 이전 기록')
                    self.render()
                elif kind=='row':
                    self.scanned+=1
                    try:r=self.history.add(value)
                    except OSError:r=dict(value,delta=None,status=value['status']+' · 저장 실패')
                    self.rows=[old for old in self.rows if (old['date'],old['time'])!=(r['date'],r['time'])]+[r];self.render()
                elif kind in ('done','error'):
                    self.busy=False;self.cal.setEnabled(True);self.all_button.setEnabled(True);self.refresh_button.setEnabled(True);self.cancel_button.hide()
                    if kind=='error':self.auto.setChecked(False);self.status.setText('조회 중단: '+value)
                    elif value:self.status.setText(value)
                    elif self.scanned:self.status.setText('실시간 감지완료!')
                    self.schedule();self.render()
                elif kind=='mobile_scan' and not self.busy:self.cal.setSelectedDate(QDate.fromString(value,'yyyy-MM-dd'));self.load_history();self.start()
                elif kind=='batch_day':self.batch_info=value;self.render()
                elif kind=='chat_status':self.chat_state.setText(value['text']);self.chat_send.setEnabled(value['connected']);self.chat_log.setToolTip(value['text']);self.chat_mode.setText('LIVE' if value['text'].startswith('실시간 무전 연결') else '3초' if value['connected'] else 'OFF');self.chat_mode.setToolTip(value['text'])
                elif kind=='chat_sent':
                    if self.chat_text.text().strip()==value:self.chat_text.clear()
                elif kind=='chat_send_error':self.chat_state.setText(value);self.chat_text.setToolTip(value);self.chat_log.appendPlainText('[전송 오류] '+value)
                elif kind=='chat_message':self.chat_log.appendPlainText('['+value['time']+'] '+value['name']+' : '+value['text'])
                self.publish()
        except queue.Empty:pass
    def tick(self):
        self.elapsed.setText(f'{int(time.monotonic()-self.started)}초 경과' if self.busy else '')
        known={r['time']:r for r in self.history.rows(today())}
        known.update({r['time']:r for r in self.rows if r['date']==today()})
        self.professor.set_message(countdown_message(known.values(),slots=self.known_slots.get(today())))
    def export(self):
        if not self.rows:return
        path,_=QFileDialog.getSaveFileName(self,'CSV 저장','Galaxy_'+self.day()+'.csv','CSV (*.csv)')
        if not path:return
        try:
            with open(path,'w',newline='',encoding='utf-8-sig') as f:
                w=csv.writer(f);w.writerow(('날짜','공연 시간','정원','예약 추정','증감','선택 가능','확인 시각','상태'))
                for r in self.rows:w.writerow((r['date'],r['time'],r['capacity'],r['booked'],r.get('delta'),r['selectable'],r['checked'],r['status']))
            self.status.setText('CSV 저장 완료')
        except OSError as e:QMessageBox.warning(self,'저장 실패',str(e))
    def restore_chat(self):
        self.chat_auto=True
        try:
            default=json.loads((ROOT/'team_chat.json').read_text(encoding='utf-8'))
            self.chat_address.setText(default['code'])
        except (OSError,ValueError,KeyError):self.chat_auto=False
        try:
            saved=json.loads((ROOT/'chat_settings.json').read_text(encoding='utf-8'))
            self.chat_address.setText(saved['code']);self.chat_name.setText(saved['name']);self.chat_auto=bool(saved.get('auto',True))
        except (OSError,ValueError,KeyError):pass
    def save_chat(self,auto):
        self.chat_auto=auto
        try:
            path=ROOT/'chat_settings.json';tmp=path.with_suffix('.tmp')
            tmp.write_text(json.dumps({'code':self.chat_address.text().strip(),'name':self.chat_name.text().strip(),'auto':auto},ensure_ascii=False),encoding='utf-8');tmp.replace(path)
        except OSError:
            self.chat_log.appendPlainText('[설정] 연결은 유지되지만 자동 연결 설정을 저장하지 못했습니다.')
    def host_chat(self):
        try:
            self.chat_send.setEnabled(False);self.chat_mode.setText('...');self.chat_log.clear();self.chat_address.setText(self.chat.host(self.chat_name.text()));self.chat_state.setText('새 방 코드를 만들었습니다. 다른 직원에게 공유하세요.');self.save_chat(True)
        except (OSError,ValueError) as e:self.chat_state.setText('무전방 열기 실패: '+str(e))
    def join_chat(self):
        try:
            self.chat_send.setEnabled(False);self.chat_mode.setText('...');self.chat_log.clear();self.chat.connect(self.chat_address.text(),self.chat_name.text());self.chat_state.setText('무전기상태 점검중..');self.save_chat(True)
        except (OSError,ValueError) as e:self.chat_state.setText(str(e))
    def leave_chat(self):
        old=self.chat;self.chat=Chat(self.events);threading.Thread(target=old.disconnect,daemon=True).start();self.chat_send.setEnabled(False);self.chat_mode.setText('OFF');self.chat_state.setText('무전 연결을 종료했습니다. 다음 실행도 자동 연결하지 않습니다.');self.save_chat(False)
    def copy_chat(self):
        if self.chat_address.text():QApplication.clipboard().setText(self.chat_address.text());self.chat_state.setText('무전방 주소를 복사했습니다.')
    def send_chat(self):
        text=self.chat_text.text().strip()
        if not text:return
        try:self.chat.send(text)
        except OSError as e:self.chat_state.setText(str(e));self.chat_send.setEnabled(False)
    def closeEvent(self,event):
        threading.Thread(target=self.chat.disconnect,daemon=True).start();self.closing=True;self.stop.set();self.jobs.put(None);self.res_timer.stop();self.poll_timer.stop();self.clock.stop()
        if self.services:threading.Thread(target=self.mobile.close,daemon=True).start()
        event.accept()

if __name__=='__main__':
    if sys.platform=='win32':
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('GalaxyRobotPark.ReservationMonitor')
    app=QApplication(sys.argv);app.setWindowIcon(QIcon(str(ROOT/'assets'/'robocrew.ico')));load_pixel_fonts();app.setStyle('Fusion');app.setStyleSheet(STYLE);app.setFont(pixel_font())
    preview='--preview' in sys.argv;win=App(services=not preview)
    if preview:
        win.rows=[{'date':win.day(),'time':t,'capacity':200,'booked':b,'selectable':200-b,'checked':win.day()+' 11:20:00','delta':d,'status':'디자인 예시','cached':False} for t,b,d in [('오전 10:00',156,8),('오후 12:00',182,12),('오후 2:30',138,5),('오후 4:30',94,3),('오후 6:30',61,0)]];win.render();win.status.setText('디자인 미리보기 · 표시된 인원은 예시 데이터입니다.');win.progress.setValue(100)
    else:win.load_history()
    screen=app.primaryScreen()
    if screen:
        area=screen.availableGeometry()
        width=max(1,area.width()-40);height=max(1,area.height()-40)
        win.setMinimumSize(min(1080,width),min(760,height))
        win.resize(min(1360,width),min(860,height))
        frame=win.frameGeometry();frame.moveCenter(area.center());win.move(frame.topLeft())
    win.show()
    if screen:
        def center_window():
            frame=win.frameGeometry();frame.moveCenter(screen.availableGeometry().center());win.move(frame.topLeft())
        QTimer.singleShot(0,center_window)
    if preview:
        path=sys.argv[sys.argv.index('--preview')+1]
        QTimer.singleShot(600,lambda:(win.grab().save(path),win.close(),app.quit()))
    sys.exit(app.exec())
