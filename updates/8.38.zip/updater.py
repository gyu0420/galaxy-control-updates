"""Signed, staged updates. The running installation is never overwritten."""
import base64, hashlib, json, os, re, shutil, tempfile, urllib.request, zipfile
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
VERSION='8.38'
STATE_FILES=('reservation_history.json','chat_settings.json','settings.json','crew_progress.json','team_chat.json','update_source.json')
MAX_PACKAGE=50*1024*1024

def base_dir():
    return Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local/share')))/'GRP'
def version(value):
    if not re.fullmatch(r'\d+\.\d+(?:\.\d+)?',value):raise ValueError('잘못된 버전 번호입니다.')
    return tuple(map(int,value.split('.')))+(0,)*(3-len(value.split('.')))
def atomic_json(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8');os.replace(temp,path)
def config(root):
    local=base_dir()/'update_source.json'
    source=local if local.exists() else root/'update_source.json'
    return json.loads(source.read_text(encoding='utf-8')) if source.exists() else {'manifest_url':''}
def save_source(url):
    if url and urlparse(url).scheme!='https':raise ValueError('HTTPS 주소를 입력해주세요.')
    atomic_json(base_dir()/'update_source.json',{'manifest_url':url})
def download(url,limit):
    if urlparse(url).scheme!='https':raise ValueError('업데이트는 HTTPS 주소만 사용할 수 있습니다.')
    request=urllib.request.Request(url,headers={'User-Agent':'GalaxyControlUpdater/1'})
    with urllib.request.urlopen(request,timeout=12) as response:
        if urlparse(response.url).scheme!='https':raise ValueError('안전하지 않은 다운로드 주소입니다.')
        data=response.read(limit+1)
    if len(data)>limit:raise ValueError('업데이트 파일이 너무 큽니다.')
    return data
def verified_manifest(raw,root):
    envelope=json.loads(raw)
    payload=base64.b64decode(envelope['payload'],validate=True)
    public=base64.b64decode((root/'update_public_key.txt').read_text().strip(),validate=True)
    Ed25519PublicKey.from_public_bytes(public).verify(base64.b64decode(envelope['signature'],validate=True),payload)
    m=json.loads(payload)
    version(m['version'])
    if not re.fullmatch('[0-9a-f]{64}',m['sha256']):raise ValueError('잘못된 파일 검증 값입니다.')
    if m.get('schema')!=1:raise ValueError('지원하지 않는 업데이트 형식입니다.')
    return m

def stage(root,fetch=download):
    source=config(root).get('manifest_url','').strip()
    if not source:return '업데이트 주소 미연결'
    manifest=verified_manifest(fetch(source,64*1024),root)
    if version(manifest['version'])<=version(VERSION):return '최신 버전입니다.'
    package=fetch(manifest['url'],MAX_PACKAGE)
    if hashlib.sha256(package).hexdigest()!=manifest['sha256']:raise ValueError('업데이트 파일 검증에 실패했습니다.')
    updates=base_dir()/'updates';updates.mkdir(parents=True,exist_ok=True)
    dest=updates/('v'+manifest['version'])
    # Avoid changing a version that another running instance may be using.
    if dest.exists():
        if (dest/'PACKAGE_SHA256').read_text().strip()!=manifest['sha256']:raise ValueError('동일 버전의 파일 내용이 다릅니다.')
    else:
        with tempfile.TemporaryDirectory(dir=updates) as temporary:
            temporary=Path(temporary);archive=temporary/'package.zip';archive.write_bytes(package)
            extract=temporary/'ready';extract.mkdir()
            with zipfile.ZipFile(archive) as z:
                infos=z.infolist()
                if sum(i.file_size for i in infos)>MAX_PACKAGE*4:raise ValueError('압축 해제 크기가 너무 큽니다.')
                for i in infos:
                    name=i.filename
                    part=PurePosixPath(name)
                    if '\\' in name or ':' in name or part.is_absolute() or '..' in part.parts or (i.external_attr>>16)&0o170000==0o120000:
                        raise ValueError('잘못된 업데이트 경로입니다.')
                    if part.parts and part.parts[0] in STATE_FILES:raise ValueError('업데이트에 개인 설정 파일이 포함되어 있습니다.')
                z.extractall(extract)
            for required in ('app.py','launch.py','updater.py','assets/fonts/Galmuri11.ttf','update_public_key.txt','release_version.txt'):
                if not (extract/required).is_file():raise ValueError('업데이트 구성 파일이 없습니다: '+required)
            if (extract/'release_version.txt').read_text().strip()!=manifest['version']:raise ValueError('업데이트 버전이 일치하지 않습니다.')
            if (extract/'update_public_key.txt').read_bytes()!=(root/'update_public_key.txt').read_bytes():raise ValueError('업데이트 서명 키가 일치하지 않습니다.')
            if (extract/'requirements.txt').read_bytes()!=(root/'requirements.txt').read_bytes():raise ValueError('설치 구성 변경은 별도 설치가 필요합니다.')
            for file in extract.rglob('*.py'):compile(file.read_bytes(),str(file),'exec')
            (extract/'PACKAGE_SHA256').write_text(manifest['sha256'])
            os.replace(extract,dest)
    atomic_json(base_dir()/'pending_update.json',{'path':str(dest),'version':manifest['version']})
    return '새 버전 '+manifest['version']+' 준비 완료 · 다음 실행부터 적용됩니다.'

def select_installation(original):
    """Called before app imports. Copy the latest user data at switch time."""
    base=base_dir();current=original
    active=base/'active_update.json'
    if active.exists():
        selected=Path(json.loads(active.read_text())['path'])
        if selected.is_relative_to(base/'updates') and (selected/'app.py').is_file():current=selected
    pending=base/'pending_update.json'
    if pending.exists():
        target=Path(json.loads(pending.read_text())['path'])
        if not target.is_relative_to(base/'updates') or not (target/'app.py').is_file():raise ValueError('업데이트 설치 경로가 잘못되었습니다.')
        if target!=current:
            for name in STATE_FILES:
                if (current/name).exists():shutil.copy2(current/name,target/name)
            atomic_json(active,{'path':str(target),'previous':str(current)})
        pending.unlink();current=target
    return current
