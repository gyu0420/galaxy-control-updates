@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CreateShortcut.ps1"
if errorlevel 1 (
  echo Could not create desktop shortcut.
  pause
  exit /b 1
)
echo Desktop shortcut created with Robo Crew icon.
pause
